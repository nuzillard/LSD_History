/*
    file: OutlsdSrc/smiles.c
    Copyright(C)2000 CNRS - FRE 2715 - Jean-Marc Nuzillard

    This file is part of LSD.

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define FALSE 0
#define TRUE 1
#define X 1000
#define MAX_LEN 200
#define STRL 16
#define MAX_NA 60
#define MAX_NL 100
#define MAX_UC 60



struct atom {
	int utile ;	/* inutile */
	char elt[3] ;	/* symbole de l'element */
	int valence ;	/* inutile */
	int mult ;	/* inutile */
	int hybrid ;	/* inutile */
	int equstat ;	/* inutile */
	int iequ ;	/* inutile */
	int nlmax ;	/* inutile */
	int nlia ;	/* nombre de liaisons */
	int lia[4] ;	/* liste des liaisons */
	int ordre[4] ;	/* ordre des liaisons */
	int loc3D ; } ;	/* inutile */

int una ;	/* nombre d'atomes de l'unite connexe (uc) 	*/
int unl ;	/* nombre de liaisons de l'uc			*/
char buf[MAX_LEN] ;	/* buffer de la chaine smiles 		*/
int ibuf ;	/* index sur buf				*/
int ue1[MAX_NL], ue2[MAX_NL] ;	/* extremites des liaisons de l'uc */
int utypl[MAX_NL] ;	/* ordre de liaison des liaisons de l'uc 	*/
int nv[MAX_NA] ;	/* nombre de voisins des atomes de l'uc 	*/
char label[MAX_NA][STRL] ;/* pointeur sur les identificateurs des atomes*/
int d1[MAX_NA][MAX_NA] ;/* matrice des distances de l'uc	*/
int o_to_n[MAX_NA], n_to_o[MAX_NA] ; 
	/* conversions entre indices et indices d'uc */
int sel[MAX_NA] ;	/* 1 pour les atomes deja traites	*/

void smiles(struct atom at[], int na) ;
void chaine(int lev, int i, int j, int d, int type) ;
void w_char(char c) ;
void w_liaison(int t) ;
void w_atome(int a) ;
int get_typ(int a1, int a2) ;

/* Decoupage des infos contenus dans at en unites connexes 		*/
/* les liaisons sont reparties en liaisons de fermetures de cycles 	*/
/* et en liaisons ordinaire. Chaque uc est ensuite analysee. 		*/
/* On recheche la matrice de toutes les distances entre atomes 		*/
/* On seleclectionne les atomes les plus eloignes et on appelle 	*/
/* la fonction chaine qui va recursivement decouper la molecule 	*/
/* en morceaux sans branchment. 					*/

void smiles(struct atom at[], int na) {

int nl ; 		/* nbr de liaisons 				*/
int i, j, k, x, il ; 	/* indices ou atomes courants 			*/
int typl[MAX_NL], e1[MAX_NL], e2[MAX_NL], st[MAX_NL] ; 
			/* caracteristiques des liaisons 		*/
int uca[MAX_NA], ucl[MAX_NL] ; 	
			/* pour les atomes et les liaisons, no. de l'uc */
int t ; 		/* type de liaison, puis variable courante 	*/
int nc1, nc2, nc3 ; 	/* numeros d'uc 				*/
int nuc, iuc, indxuc, nc ;	
			/* nombre, indice, no. d'uc 			*/
int cindx[MAX_UC], cpop[MAX_UC] ;
		 	/*index et population des uc classees 		*/
int d2[MAX_NA][MAX_NA] ;
		 	/* distances intermediaires			*/
int ust[MAX_NL] ; 	/* statut des liaisons de l'uc (fermeture) 	*/
char *a ;		/* chaine courante 				*/
int a1, a2 ;		/* extremites de liaisons			*/
int l1, l2 ;		/* pour calculer les distances			*/
int im, jm, dm, dij ;	/* pour trouver la plus grande ficelle		*/
int z, zz ;		/* pour les impressions de controle		*/

ibuf = 0 ;

/* verifier si tous les atomes utiles sont complets */

for(i=0 ; i<=na ; i++) if(at[i].utile && at[i].nlia != at[i].nlmax) {
printf("outlsd: option 5 incompatible avec des structures partielles\n") ;
exit(1) ; }

/* compter les liaisons */

nl = 0 ;
for(i=1 ; i<=na ; i++) nl += at[i].nlia ;
nl /= 2 ;
/* printf("il y a %d atomes et %d liaisons\n", na, nl) ; */

/* remplir e1, e2, typl */

il = 0 ;
for (t=2 ; t>0 ; t--) /* les doubles puis les simples */
	for(i=1 ; i<na ; i++)
		for(j=0 ; j<at[i].nlia ; j++) 
			if(i < (x = at[i].lia[j]) && at[i].ordre[j] == t) {
				e1[il] = i ;
				e2[il] = x ;
				typl[il] = t ;
				il++ ;}

/* initialiser les no. d'uc des atomes */

for(i=1 ; i<=na ; i++) uca[i] = i ;
nc3 = na + 1 ;
for(i=0 ; i<nl ; i++) st[i] = FALSE ;
for(i=0 ; i<nl ; i++) {
	nc1 = uca[e1[i]] ;
	nc2 = uca[e2[i]] ;
	if(nc1 == nc2) continue ; /* fermeture */
	for(j=1 ; j<=na ; j++)
		if(uca[j] == nc1 || uca[j] == nc2) uca[j] = nc3 ;
	nc3++ ;
	st[i] = TRUE ; }/* non fermeture */

/* reattribution des uca */

nuc = 0 ;
for(;;) {
	for(i=1 ; i<=na && uca[i]<0 ; i++) ;
	if(i>na) break ;
	nc = uca[i] ; 
	nuc-- ;
	for(i=1 ; i <= na ; i++)
		if(uca[i] == nc) uca[i]=nuc ; }
nuc = -nuc ; /* nombre d'uc */
for(i=1 ; i<=na ; i++) uca[i] = -uca[i]-1 ;
for(i=0 ; i<nl ; i++) ucl[i] = uca[e1[i]] ;

/* for(z=0 ; z<nl ; z++) printf("%4d%4d %c %4d%4d%4d\n", e1[z], e2[z], 
	(typl[z] == 1) ? '-' : '=', uca[e1[z]], uca[e2[z]], st[z]) ;
printf("il y a %d unite%s connexe\n", nuc, (nuc>1) ? "s" : "") ; */

/* population et index des uc */
for(iuc=0 ; iuc < nuc ; iuc++) cpop[iuc] = 0 ;
for(iuc=0 ; iuc < nuc ; iuc++) {
	for(i=1 ; i<=na ; i++) if(uca[i] == iuc) cpop[iuc]++ ;
	cindx[iuc] = iuc ; }

/* classement des parties connexes par ordre de population decroissant */

for(i=0 ; i<nuc-1 ; i++) for(j=i+1 ; j<nuc ; j++) 
	if(cpop[i] < cpop[j]) {
		t = cpop[i] ;
		cpop[i] = cpop[j] ;
		cpop[j] = t ;
		t = cindx[i] ;
		cindx[i] = cindx[j] ;
		cindx[j] = t ; }

/* for(z=0 ; z<nuc ; z++) 
	printf("unite %4d : no. %4d : %4d atomes\n", z, cindx[z], cpop[z]) ; */

/* boucle de traitement des uc */

for(iuc=0 ; iuc<nuc ; iuc++) {
	indxuc = cindx[iuc] ;
	una = cpop[iuc] ;
	unl = 0 ; /* compter les liaisons de l'uc */
	for(i=0 ; i<nl ; i++) if(ucl[i] == indxuc) unl++ ;
	for(i=0 ; i<una ; i++) sel[i] = FALSE ; /* deselection */

/* correspondances entre atomes */

	j = 0 ;
	for(i=1 ; i<=na ; i++) if(uca[i] == indxuc) {
		o_to_n[i] = j ;
		n_to_o[j] = i ;
		nv[j] = at[i].nlia ;
		j++ ; }

/* caracteristiques des liaisons */

	j = 0 ;
	for(i=0 ; i<nl ; i++) if(ucl[i] == indxuc) {
		ue1[j] = o_to_n[e1[i]] ;
		ue2[j] = o_to_n[e2[i]] ;
		ust[j] = 1 - st[i] ; /* 1 pour les fermetures */
		utypl[j] = typl[i] ;
		j++ ; }

/* labels des atomes */

	for(i=0 ; i<una ; i++) strcpy(label[i], at[n_to_o[i]].elt) ;

	j = 1 ;
	for(i=0 ; i<unl ; i++) if(ust[i]) {
		a = label[ue1[i]] ;
		a += strlen(a) ;
		if(j>9) { sprintf(a, "%c", '%') ; a++ ; }
		sprintf(a, "%d", j) ;
		a = label[ue2[i]] ;
		a += strlen(a) ;
		if(j>9) { sprintf(a, "%c", '%') ; a++ ; }
		sprintf(a, "%d", j) ;
		nv[ue1[i]]-- ;
		nv[ue2[i]]-- ;
		j++ ; }		

/* for(z=0 ; z<una ; z++)
	printf ("atome %3d : old %3d : element %s : %d voisins\n",
		z, n_to_o[z], label[z], nv[z]) ; */


/* d1 est la matrice des distances */

	for(i=0 ; i<una ; i++) for(j=0 ; j<una ; j++) d1[i][j] = X ;
	for(i=0 ; i<unl ; i++) if(!ust[i]) {
		a1 = ue1[i] ;
		a2 = ue2[i] ;
		d1[a1][a2] = d1[a2][a1] = 1 ; }
	for(k=0 ; k<una ; k++) {
		for(i=0 ; i<una ; i++) for(j=0 ; j<una ; j++) {
			l1 = d1[i][j] ;
			l2 = d1[i][k] + d1[k][j] ;
			d2[i][j] = (l1 < l2) ? l1 : l2 ; }
		for(i=0 ; i<una ; i++) for(j=0 ; j<una ; j++) 
			d1[i][j] = d2[i][j] ; }
	for(i=0 ; i<una ; i++) d1[i][i] = 0 ;

/* for(z=0 ; z<una ; z++) {
	for(zz=0 ; zz<una ; zz++) printf("%3d", d1[z][zz]) ;
	printf("\n") ; } */

/* chemin le plus long */

	dm = im = jm = 0 ;
	for(i=0 ; i<una-1 ; i++) if(nv[i] == 1)
		for(j=i+1 ; j<una ; j++) if(nv[j] == 1) {
			dij = d1[i][j] ;
			if(dij > dm) {
				dm = dij ;
				im = i ;
				jm = j ; }
	}
	chaine(0, im, jm, dm, 1) ;

} /* for iuc */
w_char('\n') ;
printf("%s", buf) ;
} /* smiles */



void chaine(int lev, int i, int j, int d, int type) {
int k ;			/* atome courant entre i et j		*/
int x ;			/* x = d(i, k) ;			*/
int kp ;		/* d(i, kp) = x+1			*/
int I ;			/* attache de la chaine laterale	*/
int t ; 		/* type de la liaison I-k		*/
int Jm ;		/* extremite de la chaine laterale 	*/
int Dm ;		/* Dm = d(I, Jm)			*/
int J ;			/* J courant				*/
int D ;			/* D courant				*/

/* printf("%2d : la plus longue chaine va de %d a %d et mesure %d liaisons \n",
	lev, n_to_o[i], n_to_o[j], d) ; */

if(lev) {
	w_char('(') ;
	w_liaison(type) ; } /* liaison entre chaines */
w_atome(i) ;
/* printf("***   %s\n", buf) ; */
if(d) { /* la chaine laterale possede plus d'un atome */
	k = i ;
	for(x=1 ; x<=d ; x++) {
		sel[k] = TRUE ;
		for(kp=0 ; !(d1[i][kp] == x && d1[kp][j] == d-x) ; kp++) ;
/* printf("entre %d et %d : %d\n", n_to_o[i], n_to_o[j], n_to_o[k]) ; */
		if(nv[k] > 2) for(I=0 ; I<una ; I++) {
/* printf("essai I = %d \n", n_to_o[I]) ; */
			if(d1[I][k] != 1) continue ; /* I voisin de k */
/* printf(" %d est voisin de %d\n", n_to_o[I], n_to_o[k]) ; */
			if(I == kp) continue ; /* I pas sur la chaine */
/* printf(" %d diff de kp : %d\n", n_to_o[I], n_to_o[kp]) ; */
			if(sel[I]) continue ; /* I pas sur la chaine */
/* printf(" %d non selectionne\n", n_to_o[I]) ; */
			t = get_typ(I, k) ;
			if(nv[I] == 1) chaine(lev + 1, I, I, 0, t) ;
			else {
				Jm = 0 ; Dm = 0 ;
				for(J=0 ; J<una ; J++) {
					if(nv[J] != 1) continue ;
					if(sel[J]) continue ;
					D = d1[I][J] ;
					if(d1[k][J] != D+1) continue ;
					if(D > Dm) { Jm = J ; Dm = D ;}
				}
				chaine(lev + 1, I, Jm, Dm, t) ;
			} /* si la chaine laterale a plus de 1 atome */
		} /* si k est branche */
		t = get_typ(k, kp) ;
		w_liaison(t) ;
		w_atome(kp) ;
/* printf("***   %s\n", buf) ; */
		k = kp ;
	} /* pour tous les atomes entre i et j */
} /* if */
sel[j] = TRUE ;
if(lev) w_char(')') ; /* fin de chaine laterale */
else w_char(' ') ; /* fin de chaine smiles */
/* printf("***   %s\n", buf) ; */
return ;
} /* chaine */

void w_char(char c) {
sprintf(buf + ibuf, "%c", c) ; ibuf++ ;
}

void w_liaison(int t) {
if(t != 1) {
 	sprintf(buf + ibuf, "%c", (t == 2) ? '=' : '#') ; ibuf++ ; }
}

void w_atome(int a) {
	sprintf(buf + ibuf, "%s", label[a]) ;
	ibuf += strlen(label[a])  ;
}

int get_typ(int a1, int a2) {
int i;
for(i=0 ; i<unl ; i++) 
	if(ue1[i] == a1 && ue2[i] == a2 ||
	   ue1[i] == a2 && ue2[i] == a1) return utypl[i] ;
}


