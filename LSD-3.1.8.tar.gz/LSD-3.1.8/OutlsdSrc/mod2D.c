/*
    file: OutlsdSrc/mod2D.c
    Copyright(C)2000 CNRS - FRE 2715 - Jean-Marc Nuzillard

    This file is part of LSD.

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <math.h>
#include "matutil.h"
#include "jacobi.h"
#include "defs.h"

#define A -0.3
#define B 0.000001
#define C 0.2
#define THRS 1.0

extern struct atom at[MAX_ATOMES] ;
extern int isol ;
extern int max_atomes ;
extern struct at3D a[MAX_AT3D] ;
extern molflag ;

void out2D() ;
void mini(int nat, int dim) ;
extern int bound(int i, int j) ;
extern double myrand(double range) ;
extern double car(double x)  ;
void aplatir(int n) ;
void wr2dDRAW(int n) ;
void wr2dMOL(int n) ;

void out2D() 
{
	double arete ;
	int ia, z, i, j, v, n ;
	struct at3D *ai ;

	arete = pow((double)max_atomes, 1.0/3) ;
	for(ia=0,z=0 ; z<=max_atomes ; z++)
	    if(at[z].utile && at[z].nlia) {
		a[ia].nom = at[z].elt ;
		a[ia].nlien = at[z].nlia ;
		a[ia].nh = at[z].mult ;
		a[ia].loc = z ;
		at[z].loc3D = ia ;
		for(i=0 ; i<3 ; i++) 
			a[ia].coor[i] = myrand(arete) ;
		for(i=0 ; i<6 ; i++) a[ia].lien[i] = 0 ;
		ia++ ;
	}
	for(i=0 ; i<ia ; i++) {
		z = a[i].loc ;
		n = at[z].nlia ;
		for(j=0 ; j<n ; j++) {
			v = at[z].lia[j] ;
			a[i].lien[j] = at[v].loc3D ;
			a[i].ordl[j] = at[z].ordre[j] ;
			a[i].flD[j] = TRUE ;
		}
	}
	mini(ia, 3) ;
	aplatir(ia) ; 
	mini(ia, 2) ; 
	if(molflag)
		wr2dMOL(ia) ;
	else
		wr2dDRAW(ia) ;
	 
}
	
void mini(int nat, int dim)
{
	struct at3D *ai, *aj ;
	int i, j, k, n, a1, a2 ;
	double rms, v[3], f, r2 ;

	rms = 1.0 ;
	for(n=0 ; n<MAX_ITER && rms>MAX_RMS ; n++) {
		for(i=0 ; i<nat ; i++) {
			ai = &a[i] ;
			for(j=0 ; j<dim ; j++) ai->dsp[j]=0.0 ;
			for(j=0 ; j<nat ; j++) {
				aj = &a[j] ;
				for(k=0 ; k<dim ; k++)
					v[k] = aj->coor[k] - ai->coor[k] ;
				r2 = car(v[0]) + car(v[1]) ;
				if(dim == 3) r2 += car(v[2]) ;
				f = (bound(i, j)) ? 
					C*(1-1/(r2 + B)) : A/car(r2+B) ;
				for(k=0 ; k<dim ; k++) ai->dsp[k] += f*v[k] ;
			}
		} 
		rms = 0.0 ;
		for(i=0 ; i<nat ; i++) for(j=0 ; j<dim ; j++)
			rms += car(a[i].dsp[j]) ;
		rms = sqrt(rms/nat) ;
		f = (rms > THRS) ? THRS/rms : 1.0 ;
		for(i=0 ; i<nat ; i++) for(j=0 ; j<dim ; j++) 
			a[i].coor[j] += f * (a[i].dsp[j]) ;
	}
}

void aplatir(int n) 
{
	double gr[3], x, y, z ;
	double max2, max3, xn, yn ;
	int i, j, iax1, iax2, iax3 ;
	double **iner, *mom, **evec ;
	unsigned int nrot ;

	iner = dmatrix(3, 3) ;
	mom = dvector(3) ;
	evec = dmatrix(3, 3) ;

	if((!iner) || (!mom) || (!evec)) {
		fprintf(stderr, "%s", "memory allocation failed.\n") ;
		exit(1) ;
	}

/* position du centre de gravite et recentrage */
	for(i=0 ; i<3 ; i++) gr[i] = 0.0 ;
	for(i=0 ; i<n ; i++) for(j=0 ; j<3 ; j++) gr[j] += a[i].coor[j] ;
	for(i=0 ; i<n ; i++) for(j=0 ; j<3 ; j++) a[i].coor[j] -= gr[j]/n ;

/* calcul de la matrice d'inertie */
	for(i=0 ; i<3 ; i++) for(j=0 ; j<3 ; j++) iner[i][j] = 0 ;
	for(i=0 ; i<n ; i++) {
		x=a[i].coor[0] ;
		y=a[i].coor[1] ;
		z=a[i].coor[2] ;
		iner[0][0] += car(y) + car(z) ;
		iner[1][1] += car(z) + car(x) ;
		iner[2][2] += car(x) + car(y) ;
		iner[0][1] -= x * y ;
		iner[1][2] -= y * z ;
		iner[2][0] -= z * x ;
	}
	iner[1][0] = iner[0][1] ;
	iner[2][1] = iner[1][2] ;
	iner[0][2] = iner[2][0] ;
/*
for(i=0 ; i<3 ; i++) {
	for(j=0 ; j<3 ; j++) {
		printf("%.6f ", iner[i][j]) ;
	}
	printf("%s", "\n") ;
}
*/

/* diagonalisation */
	switch (gsl_eigen_jacobi(3, iner, mom, evec, 1000, &nrot))
	{
		case 0 : break ;
		case 1 : fprintf(stderr, "%s", "cannot converge.\n") ; exit(1) ;
		case 2 : fprintf(stderr, "%s", "cannot allocate workspace.\n") ; exit(1) ;
	}

/* axes principaux */
	max3 = 0.0 ;
	for(i=0 ; i<3 ; i++) if(mom[i] > max3) {
		max3 = mom[i] ;
		iax3 = i ;
	}
	max2 = 0.0 ;
	for(i=0 ; i<3 ; i++) if(i != iax3 && mom[i] > max2) {
		max2 = mom[i] ;
		iax2 = i ;
	}
	iax1 = 3 - iax2 - iax3 ;

/* projection sur le plan principal */
	for(i=0 ; i<n ; i++) {
		x=a[i].coor[0] ;
		y=a[i].coor[1] ;
		z=a[i].coor[2] ;
		xn = x*evec[0][iax1] + y*evec[1][iax1] + z*evec[2][iax1] ;
		yn = x*evec[0][iax2] + y*evec[1][iax2] + z*evec[2][iax2] ;
		a[i].coor[0] = xn ;
		a[i].coor[1] = yn ;
		a[i].coor[2] = 0 ;
	}

	free_dmatrix(evec) ;
	free_dvector(mom) ;
	free_dmatrix(iner) ;
}


void wr2dDRAW(int n)
{
	int i, j ;

	printf("%3d  %3d\n", n, isol) ;
	for(i=0 ; i<n ; i++) {
		printf("%3d%3d%3s%2d  ", i, a[i].loc, a[i].nom, a[i].nlien) ;
		for(j=0 ; j<a[i].nlien ; j++) 
			printf("%3d%2d", a[i].lien[j], a[i].ordl[j]) ;
		for(j=a[i].nlien ; j<6 ; j++) printf("%3d%2d", 0, 0) ;
		for(j=0 ; j<2 ; j++) printf("%10.5f ", a[i].coor[j]) ;
		printf("\n") ;
	}
}

void wr2dMOL(int n)
{
	int i, j ;

	for(i=0 ; i<n ; i++) {
		for(j=0 ; j<2 ; j++) printf("%10.4f", a[i].coor[j]) ;
		printf("%10.4f ", 0.0) ;
		printf("%-3s 0  0  0  0  0  0  0  0  0  0  0  0\n", a[i].nom) ;
	}
}



