/*
    file: LsdSrc/start.c
    Copyright(C)2000 CNRS - UMR 6013 - Jean-Marc Nuzillard

    This file is part of LSD.

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include "defs.h"

void	start(void) ;
void	start1(int ic, int o, int p1, int p2, int p3, int p4) ;
void	hmbvar(int ic) ;
void	s_lier(int p1, int p2, int fl) ;
int	s_carb(int x) ;
int	s_hete(int x) ;
int	s_sp3(int x) ;
int	s_sp2(int x) ;
int	s_quat(int x) ;
int	s_ch(int x) ;
int	s_ch2(int x) ;
int	s_ch3(int x) ;
int	s_full(int x) ;
int	s_ge(int x, int y) ;
int	s_le(int x, int y) ;
int	s_gt(int x, int y) ;
int	s_lt(int x, int y) ;
int	s_ou(int x, int y) ;
int	s_et(int x, int y) ;
int	s_diff(int x, int y) ;
int	estvisible(int p1, int p2) ;
int	estcorrele(int p1, int p2) ;
void	s_prop(int p, int (*f)(int)) ;
void	s_cmp(int p1, int p2, int (*f)(int, int)) ;
void	s_ens(int p1, int p2, int p3, int (*f)(int, int)) ;
int	*s_adr(int p, int *al) ;
void	s_useprop(int x, int n, int l) ;
void	lier_prop(int p1, int p2) ;
int	estlie(int x, int y) ;
void	about(void) ;
void	wrln(int i) ;
void	wrln2(int y) ;
int	stoss(int i) ;

extern void	non_nul(int errno, int v) ;
extern void	check_list(int l)  ;

extern struct atom at[MAX_ATOMES] ;
extern list[MAX_LIST][MAX_ATOMES] ;
extern struct comtab coms[MAX_COM] ;
extern struct noy nucl[MAX_NUCL] ;
extern int	lignes_lues ;
extern struct crt cartes[MAX_CARTES] ;
extern int	valcorr[MAX_CORR] ;
extern int	icarte ;
extern int	max_atomes ;
extern int	icorr ;
extern int	flabout ;
extern int	flhistoire ;
extern int	fldisp ;
extern int	flverb ;
extern int	flpart ;
extern int	flstep ;
extern int	flwork ;
extern int	fldupl ;
extern int	flsubsgood ;
extern int	flsubsbad ;
extern int	elim ;
extern int	flelim ;
extern int	maxj ;
extern int	flfilt ;
extern int	base[MAX_ATOMES] ;
extern int	lnsize[MAX_LN] ;
extern int	ln[MAX_LN][MAX_LNBUF] ;
extern int	flhmbvar ;
extern int	nivdisp ;
extern struct ss_atom sub[MAX_ATOMES] ;
extern int	nssl ;
extern int	nass ;

int	htoc[MAX_ATOMES] ; /* H index to C index from HMQC data */
int	ctoh[MAX_ATOMES] ; /* C index to H index from HMQC data */
int	deflist[MAX_LIST] ; /* true if the list is defined */

void	start(void)
/*
 * initialisations and analysis of the commands read by lecture()
 */
{
	int	i, ic, ip ;

	for (i = 0 ; i < MAX_ATOMES ; i++) {
		base[i] = htoc[i] = ctoh[i] = 0 ;
	}
/* resets the base (see lsd) and the C <-> H conversion tables */
	for (i = 0 ; i < MAX_ATOMES ; i++) {
		at[i].utile = FALSE ;
		at[i].nc = at[i].nlpr = at[i].nlia = 0 ;
		at[i].equstat = -1 ;
		at[i].corrgrp = 0 ;
		at[i].ingrp = FALSE ;
	}
/* resets atoms characteristics */
	for (i = 0 ; i < MAX_CORR ; i++) {
		valcorr[i] = FALSE ;
	}
/* no valid correlation */
	for (i = 0 ; i < MAX_LIST ; i++) {
		deflist[i] = FALSE ;
	}
/* no defined list */
	for (ip = 0 ; ip < MAX_PRIO ; ip++) {
/* analyzing commands following ascending priority order */
		for (ic = 0 ; ic < icarte ; ic++) {
			if (coms[cartes[ic].opnum].prior == ip) {
/* printf("# %d priority %d command %s\n", ic+1, ip, coms[cartes[ic].opnum].op) ; */
				lignes_lues = cartes[ic].ln ;
				cartes[ic].done = TRUE ;
				start1(	ic, 
					cartes[ic].opnum, 
					cartes[ic].pars[0], 
					cartes[ic].pars[1], cartes[ic].pars[2],
				     	cartes[ic].pars[3]) ;
/* start1 does the real job */
			}
		}
	}
	if (flhmbvar) {
		for (ic = 0 ; ic < icarte ; ic++) {
			if (!cartes[ic].done) {
				hmbvar(ic) ;
			}
		}
	}
/* if there are variants in HMBC correlation, the input analysis is
 * completed by hmbvar */
	if (flverb) {
		printf("start ok\n") ;
	/*	about() ; */
	}
}


void	start1(int ic, int o, int p1, int p2, int p3, int p4)
{
	struct atom *a ;
	int	i, j, n, cardinal, x ;

	switch (o) {

	case 0 : /* VALE : valency A I */

		non_nul(200, !nucl[p1].val) ;
		non_nul(201, p2) ;
		nucl[p1].val = p2 ;
/* redefines the valency */
		break ;

	case 1 : /* MULT : multiplicity I A I I*/
		non_nul(210, p1 < MAX_ATOMES) ;
		non_nul(211, (p3 >= 2) && (p3 <= 3)) ;
		a = &at[p1] ;
		a->utile = TRUE ;
		a->element = p2 ;
		a->valence = nucl[p2].val ;
		non_nul(213, a->valence > 0) ;
		a->hybrid = 3 - p3 ; /* 0 for sp3 and 1 for sp2 */
		a->mult = p4 ;
		a->nlmax = a->valence - a->hybrid - a->mult ; /* neighbours */
		non_nul(212, a->nlmax > 0) ;
		a->extocc = a->nlmax ; /* see lsd */
		if (p1 > max_atomes) {
			max_atomes = p1 ;
/* atoms have not be defined in the natural order. never tested */
		}
		break ;

	case 2 : /* LIST : list L */
		cardinal = 0 ;
		for (x = 1 ; x <= max_atomes ; x++) {
			if (list[p1][x]) {
				non_nul(260, at[x].utile) ;
				cardinal++;
			}
		}
		for (x = max_atomes + 1 ; x < MAX_ATOMES ; x++)
			non_nul(261, !list[p1][x]) ;
		non_nul(262, cardinal) ;
		/*	printf("** liste %d **", p1) ; check_list(p1) ; printf("\n") ;*/
		deflist[p1] = TRUE ;
/* the list p1 is defined if all its elements are defined */
		break ;

	case 3 : /* CARB : carbons L */
		s_prop(p1, s_carb) ;
		break ;

	case 4 : /* HETE : heteroatoms L */
		s_prop(p1, s_hete) ;
		break ;

	case 5 : /* SP3  L*/
		s_prop(p1, s_sp3) ;
		break ;

	case 6 : /* SP2 L */
		s_prop(p1, s_sp2) ;
		break ;

	case 7 : /* QUAT : quaternary L */
		s_prop(p1, s_quat) ;
		break ;

	case 8 : /* CH   : L*/
		s_prop(p1, s_ch) ;
		break ;

	case 9 : /* CH2  : L */
		s_prop(p1, s_ch2) ;
		break ;

	case 10 : /* CH3  : L */
		s_prop(p1, s_ch3) ;
		break ;

	case 11 : /* FULL : all the defined atoms L */
		s_prop(p1, s_full) ; 
		break ;

	case 12 : /* GREQ : greater or equal L I */
		s_cmp(p1, p2, s_ge) ; 
		break ;

	case 13 : /* LEEQ : less or equal L I */
		s_cmp(p1, p2, s_le) ; 
		break ;

	case 14 : /* GRTH : strictly greater than L I */
		s_cmp(p1, p2, s_gt) ; 
		break ;

	case 15 : /* LETH : strictly small than L I */
		s_cmp(p1, p2, s_lt) ; 
		break ;

	case 16 : /* UNIO : union B B L */
		s_ens(p1, p2, p3, s_ou) ; 
		break ;

	case 17 : /* INTE : intersection B B L */
		s_ens(p1, p2, p3, s_et) ; 
		break ;

	case 18 : /* DIFF : difference B B L */
		s_ens(p1, p2, p3, s_diff) ; 
		break ;

	case 19 : /* PROP : properties B I L */
		non_nul(270, p1) ;
		if (p1 > 0) 
			s_useprop(p1, p2, p3) ;
		else {
/* p1 is a list reference */
			p1 = -p1 ;
			non_nul(271, deflist[p1]) ;
			for (x = 1 ; x <= max_atomes ; x++) {
				if (list[p1][x]) {
					s_useprop(x, p2, p3) ;
/* applies proporties to all the list's members */
				}
			}
		}
		break ;

	case 20 : /* BOND : bond I I */
		s_lier(p1, p2, 1) ;
		break ;

	case 21 : /* HMQC : hmqc I I */
		non_nul(230, at[p1].utile) ;
		ctoh[p1] = p2 ;
		non_nul(231, !htoc[p2]) ;
		htoc[p2] = p1 ;
		break ;

	case 22 : /* COSY : cosy I I */
		p1 = htoc[p1] ;
		p2 = htoc[p2] ;
		s_lier(p1, p2, 0) ;
		break ;

	case 23 : /* HMBC : hmbc V I */
		p2 = htoc[p2] ;
/* transforms the proton reference into a carbon reference */
		non_nul(251, at[p2].utile) ;
		if (p1 < 0) {
			flhmbvar = TRUE ;
			cartes[ic].done = FALSE ;
			break ;
/* treatment of fuzzy HMBC correlations is delayed */
		}
		non_nul(250, at[p1].utile) ;
		if (estvisible(p1, p2)) {
			break ;
/* the correlation does not bring anything */
		}
		if (estcorrele(p1, p2)) {
			break ;
/* the correlation is duplicated */
		}
		a = at + p1 ;
		n = a->nc ;
		a->ex[n] = icorr ;
		a->nctot = a->nc = n + 1 ;
		a->other[n] = p2 ;
		a = at + p2 ;
		n = a->nc ;
		a->ex[n] = icorr ;
		a->nctot = a->nc = n + 1 ;
		a->other[n] = p1 ;
/* updates atoms correlation data */
		valcorr[icorr++] = TRUE ;
/* global validity of the new correlation */
		break ;
	case 24 : /* ENTR : entry I */
		flabout = p1 ;
/* in order to display what has been understood from the input file */
		break ;
	case 25 : /* HIST : history I */
		flhistoire = p1 ;
/* in order to display a trace from the resolution mechanism */
		break ;
	case 26 : /* DISP : display I */
		fldisp = p1 ;
/* result as bonds or for JMNMOL */
		break ;
	case 27 : /* VERB : verbose I */
		flverb = p1 ;
		break ;
	case 28 : /* PART : partial I */
		flpart = p1 ;
/* in order to get only partial solutions */
		break ;
	case 29 : /* STEP : step I */
		flstep = p1 ;
/* for the single-step mode */
		break ;
	case 30 : /* WORK : work I */
		flwork = p1 ;
/* in order to do the job */
		break ;
	case 31 : /* MLEV maximum level I*/
		nivdisp = p1 ;
/* stop at a given heap level */
		break ;
	case 32 : /* SSTR : substructure S A V V */
		non_nul(350, p1 > 0) ;
		non_nul(351, !stoss(p1)) ;
/* p1 is a new subatom reference */
		nass++;
		non_nul(352, nass < MAX_NASS) ;
		sub[nass].ss_ref = p1 ;
		sub[nass].ss_element = p2 ;
		sub[nass].ss_hybrid = p3 ;
		if (p3 > 0) 
			non_nul(353, (p3 == 2) || (p3 == 3)) ;
		else 
			for (i = 0 ; i < lnsize[-p3] ; i++) {
				j = ln[-p3][i] ;
				non_nul(353, (j == 2) || (j == 3)) ;
			}
		sub[nass].ss_mult = p4 ;
		if (p4 >= 0) 
			non_nul(354, (p4 >= 0) && (p4 <= 3)) ;
		else 
			for (i = 0 ; i < lnsize[-p4] ; i++) {
				j = ln[-p4][i] ;
				non_nul(354, (j >= 0) && (j <= 3)) ;
			}
		sub[nass].ss_nlia = 0 ;
		sub[nass].ss_asgn = 0 ;
		sub[nass].ss_init = 0 ;
/* defines a subatom */
		break ;
	case 33 : /* ASGN : assign S I */
		i = stoss(p1) ;
		non_nul(360, i) ;
		non_nul(361, (p2 > 0) && (p2 < max_atomes) && (at[p2].utile)) ;
		non_nul(362, !sub[i].ss_asgn) ;
		sub[i].ss_asgn = p2 ;
		at[p2].asgn = i ;
/* updates substructure assignment information */
		break ;
	case 34 : /* LINK : link S S */
		non_nul(370, nssl < MAX_NSSL) ;
		i = stoss(p1) ;
		j = stoss(p2) ;
		non_nul(371, i) ;
		non_nul(373, sub[i].ss_nlia < 4) ;
		non_nul(372, j) ;
		non_nul(374, sub[j].ss_nlia < 4) ;
		sub[i].ss_lia[sub[i].ss_nlia++] = j ;
		sub[j].ss_lia[sub[j].ss_nlia++] = i ;
		nssl++;
/* set bonds between subatoms - validations could be improved */
		break ;
	case 35 : /* DUPL : duplicate solutions I */
		fldupl = p1 ;
		break ;
	case 36 : /* SUBS : subs I */
		flsubsgood = (p1 > 0) ;
		flsubsbad = (p1 < 0) ;
		break ;
	case 37 : /* ELIM : eliminate correlations I I */
		elim = p1 ;
		non_nul(380, elim >= 0) ;
		flelim = (elim > 0) ;
		maxj = p2 ;
		non_nul(381, maxj >= 0) ;
		if(maxj) {
			non_nul(382, maxj > 3) ;
		}
		break ;
	case 38 : /* FILT : filter substructure I */
		flfilt = p1 ;
		break ;
	}
} /* start1 */


void	hmbvar(int ic)
/*
 * treatment of variant HMBC correlations
 */
 
{
	int	p1, p2, s, i, j, n ;
	struct atom *a ;

	p1 = -cartes[ic].pars[0] ;
/* carbon list reference */
	p2 = htoc[cartes[ic].pars[1]] ;
/* carbon from proton through HMQC data */
	s = lnsize[p1] ;
	for (i = 0 ; (i < s) && !(estvisible(ln[p1][i], p2) || estcorrele(ln[p1][i], p2)) ; i++) 
		;
	if (i == s) {
/* p2 and each atom from p1 are neither visible (separated by 2 bonds) nor
 * correlating */
		for (j = 0 ; j < s ; j++) {
			at[ln[p1][j]].ingrp = TRUE ;
		}
/* atoms from p1 are in a group */
		a = &at[p2] ;
		n = a->nc ;
		a->ex[n] = icorr ;
		a->corrgrp++;
/* one more correlation of p2 with a group */
		a->nctot = a->nc = n + 1 ;
		a->other[n] = -p1 ;
		valcorr[icorr++] = TRUE ;
	}
}


void	s_lier(int p1, int p2, int fl)
/* 
 * initialises bonds. When called with ll being true, p1 and p2 must not
 * be previously bound 
 */
{
	int	n, paslie ;
	struct atom *a ;

	non_nul(280, at[p1].utile) ;
	non_nul(281, at[p2].utile) ;
	paslie = !estlie(p1, p2) ;
	if (fl) {
		non_nul(282, paslie) ;
	}
	if (paslie) {
/* does the job */
		a = at + p1 ;
		n = a->nlia ;
		a->lia[n] = p2 ;
		n++;
		non_nul(283, n <= a->nlmax) ;
		a->nlia = n ;

		a = at + p2 ;
		n = a->nlia ;
		a->lia[n] = p1 ;
		n++;
		non_nul(284, n <= a->nlmax) ;
		a->nlia = n ;

		lier_prop(p1, p2);
		lier_prop(p2, p1);
/* updates property information upon bonds formation */
	}
}


int	s_carb(int x)
{ 
	return at[x].element == 0 ; 
}


int	s_hete(int x)
{ 
	return at[x].element != 0 ; 
}


int	s_sp3(int x)
{ 
	return at[x].hybrid == 0 ; 
}


int	s_sp2(int x)
{ 
	return at[x].hybrid == 1 ; 
}


int	s_quat(int x)
{ 
	return s_carb(x) && at[x].mult == 0 ; 
}


int	s_ch(int x)
{ 
	return s_carb(x) && at[x].mult == 1 ; 
}


int	s_ch2(int x)
{ 
	return s_carb(x) && at[x].mult == 2 ; 
}


int	s_ch3(int x)
{ 
	return s_carb(x) && at[x].mult == 3 ; 
}


int	s_full(int x)
/* x is not used, I know... */
{ 
	return TRUE ; 
}


int	s_ge(int x, int y)
{ 
	return x >= y ; 
}


int	s_le(int x, int y)
{ 
	return x <= y ; 
}


int	s_gt(int x, int y)
{ 
	return x > y ; 
}


int	s_lt(int x, int y)
{ 
	return x < y ; 
}


int	s_ou(int x, int y)
{ 
	return x || y ; 
}


int	s_et(int x, int y)
{ 
	return x && y ; 
}


int	s_diff(int x, int y)
{ 
	return x ? (!y) : x ; 
}


int	estvisible(int p1, int p2)
/*
 * true either if p1 and p2 are bound or if they share a common neighbour
 */
{
	int	i, n, x ;

	if (estlie(p1, p2)) {
		return TRUE ;
	}
/* p1 and p2 are bound */
	n = at[p1].nlia ;
	if (!n || !at[p2].nlia) {
		return FALSE ;
	}
/* p1 or p2 has no bond */
	for (i = 0 ; (i < n) && ((x = at[p1].lia[i]), !estlie(x, p2)) ; i++) 
		;
/* ugly but efficient - x is the hypothetic common neighbour */
	return (i != n) ;
}


int	estcorrele(int p1, int p2)
/*
 * return true if the atoms p1 and p2 are correlating 
 */
{
	int	i, n ;

	n = at[p1].nc ;
	for (i = 0 ; (i < n) && (at[p1].other[i] != p2) ; i++) 
		;
	return (i != n) ;
}


void	s_prop(int p, int (*f)(int))
/*
 * builts the list number p according to the atom's property f
 */
{
	int	cardinal, x, r ;

	cardinal = 0 ;
	for (x = 1 ; x <= max_atomes ; x++) {
		r = at[x].utile && (*f)(x) ;
		list[p][x] = r ;
		if (r) {
			cardinal++;
		}
	}
	non_nul(290, cardinal) ;
	/*	printf("** liste %d **", p) ; check_list(p) ; printf("\n") ; */
	deflist[p] = TRUE ;
}


void	s_cmp(int p1, int p2, int (*f)(int, int))
/* 
 * selects atoms according to a comparison function f 
 */
{
	int	cardinal, x, r ;

	cardinal = 0 ;
	for (x = 1 ; x <= max_atomes ; x++) {
		r = at[x].utile && (*f)(x, p2) ;
		list[p1][x] = r ;
		if (r) {
			cardinal++;
		}
	}
	non_nul(300, cardinal) ;
	/*	printf("** liste %d **", p1) ; check_list(p1) ; printf("\n") ; */
	deflist[p1] = TRUE ;
}


void	s_ens(int p1, int p2, int p3, int (*f)(int, int))
/*
 * operates sets function f. l1 and l2 are 2 lists used in order
 * to store sets made of a single element
 */
{
	int	l1[MAX_ATOMES], l2[MAX_ATOMES] ;
	int	*a1, *a2, x, r, cardinal ;

	a1 = s_adr(p1, l1) ;
	a2 = s_adr(p2, l2) ;
	cardinal = 0 ;
	for (x = 1 ; x <= max_atomes ; x++) {
		r = at[x].utile && (*f)(a1[x], a2[x]) ;
		list[p3][x] = r ;
		if (r) 
			cardinal++;
	}
	non_nul(310, cardinal) ;
	/*	printf("** liste %d **", p3) ; check_list(p3) ; printf("\n") ; */
	deflist[p3] = TRUE ;
}


int	*s_adr(int p, int *al)
/* returns the address of a set that can be a single element, too */
{
	int	i ;

	if (p > 0) {
/* generates a set with a single element : p */
		non_nul(320, p <= max_atomes) ;
		for (i = 1 ; i <= max_atomes ; i++) 
			al[i] = FALSE ;
		al[p] = TRUE ;
		return al ;
	} else {
		p = -p ;
/* p is a list reference */
		non_nul(321, deflist[p]) ;
		return list[p] ;
	}
}


void	s_useprop(int x, int n, int l)
/*
 * atom x has exactly n neighbours in the list l
 */
{
	int	i, j, k, go ;

	non_nul(330, n >= 0) ;
	if (n == 0) {
/* 0 neighbours means all neighbours */
		n = at[x].nlmax ;
	}
	i = at[x].nlpr ;
/* i is the number of property lists */
	at[x].lpr[i] = l ;
	at[x].occ[i] = n ;
	at[x].extocc -= n ;
/* number of atoms out of all the property lists */
	non_nul(331, at[x].extocc >= 0) ;
	at[x].nlpr++;
	go = TRUE ;
	for (j = 0 ; (j < i) && go ; j++) {
/* looking inside of all the other property lists of x */
		for (k = 1 ; k <= max_atomes && !( at[k].utile &&  list[l][k] &&  list[at[x].lpr[j]][k]) ; k++) 
			;
		go = (k == max_atomes + 1) ;
/* go becomes false if these is an atom k belonging to l and to the jth 
 * property list of x. That means that property list must not overlap */
	}
	non_nul(332, go) ;
}


void	lier_prop(int p1, int p2)
/*
 * property data management upon bond formation 
 */
{
	int	i, n, *a ;

	n = at[p1].nlpr ;
	for (i = 0 ; (i < n) && (!list[at[p1].lpr[i]][p2]) ; i++) 
		;
/* i is the index of the p1's property list where p2 is in */
	a = (i == n) ? &at[p1].extocc : &at[p1].occ[i] ;
/* address of the number of occurences to be decremented */
	non_nul(340, (*a) > 0) ;
	(*a)--;
}


int	estlie(int x, int y)
/*
 * returns true if x and y are bound
 */
{
	int	i, n ;

	n = at[x].nlia ;
	if (!n || !at[y].nlia) {
		return FALSE ;
	}
	for (i = 0 ; (i < n) && (at[x].lia[i] != y) ; i++) 
		;
/* y is x's ith neighbour */
	return (i != n) ;
}


void	about()
/*
 * displays what has been understood from the input data.
 * If bonds are established using either the BOND or the COSY commands,
 * correlation and property information are modified accordingly.
 * Therefore there can be an appearent mismatch between the input file
 * and the listing produced by about()
 */
{
	struct atom *a ;
	int	i, x, n ;

	for (x = 1 ; x <= max_atomes ; x++) {
		a = &at[x] ;
		if (!a->utile) {
			continue ;
		}
		printf("atom %d, element %s, hybridization sp%d, ",
			x, nucl[a->element].sym, 3 - a->hybrid) ;
		n = a->mult ;
		printf("bears %d hydrogen%s \n",  n, (n > 1) ? "s" : " ") ;
		n = a->nlpr ;
		if (n) {
			printf("\towns %d property list%s \n", n, (n > 1) ? "s" : " ") ;
			for (i = 0 ; i < n ; i++) {
				printf("\t\t %d neighbour%s among : ",
					a->occ[i], (a->occ[i] > 1) ? "s" : " ") ;
				check_list(a->lpr[i]) ;
				printf("\n") ;
			}
		}
		n = a->nlia ;
		if (n) {
			printf("\towns %d bond%s with", n, (n > 1) ? "s" : " ") ;
			for (i = 0 ; i < n ; i++) {
				printf("%3d", a->lia[i]) ;
			}
			printf("\n") ;
		}
		n = ctoh[x] ;
		if (n) {
			printf("\tbears hydrogen %d\n", n) ;
		}
		n = a->nctot ;
		if (n) {
			int	j ;

			for (j = 0 ; j < n &&  !((a->other[j] > 0) && valcorr[a->ex[j]]) ; j++) 
				;
			if (j != n) {
				printf("\tcorrelates with : ") ;
				for (i = 0 ; i < n ; i++) {
					if ((a->other[i] > 0) && valcorr[a->ex[i]]) {
						printf("%3d", a->other[i]) ;
					}
				}
				printf("\n") ;
			}
			if (a->corrgrp) {
				for (i = 0 ; i < n ; i++) {
					if ((a->other[i] < 0) && valcorr[a->ex[i]]) {
						printf("\tcorrelates with an atom among : ") ;
						wrln(-a->other[i]) ;
						printf("\n") ;
					}
				}
			}
		}
		n = a->equstat ;
		if (n >= 0) {
			printf("\telement %d from equivalence class %d\n", a->iequ, n) ;
		}
		n = a->asgn ;
		if (n > 0) {
			printf("\tassignment of sub-atom %d\n",  sub[n].ss_ref) ;
		}
	}
	/* sous-structure */
	if (nass) {
		printf("sub-structure\n") ;
		if (flsubsgood) {
			printf("search for the existence of the substructure\n") ;
		} else if (flsubsbad) {
			printf("search for the non-existence of the substructure\n") ;
		} else {
			printf("substructural information ignored\n") ;
		}
		for (x = 1 ; x <= nass ; x++) {
			printf("\tsub-atom %d\n", sub[x].ss_ref) ;
			printf("\t\telement %s\n",  nucl[sub[x].ss_element].sym) ;
			printf("\t\tmultiplicity : ") ;
			wrln2(sub[x].ss_mult) ;
			printf("\t\thybridization : ") ;
			wrln2(sub[x].ss_hybrid) ;
			n = sub[x].ss_asgn ;
			if (n) {
				printf("\t\tassignment of atom : %d\n", n) ;
			}
			printf("\t\tbound to : ") ;
			for (i = 0 ; i < sub[x].ss_nlia ; i++) {
				printf("%d ", sub[sub[x].ss_lia[i]].ss_ref) ;
			}
			printf("\n") ;
		}
	}
/* looks messy but is self-explanatory */
}


void	wrln(int i)
/*
 * writes the ith numerical list. No \n issued
 */
{
	int	j ;

	for (j = 0 ; j < lnsize[i] ; j++) {
		printf("%d ", ln[i][j]) ;
	}
}


void	wrln2(int y)
/*
 * writes either a numerical list or an integer. 
 */
{
	if (y >= 0) {
		printf("%d\n", y) ;
	}
	else {
		wrln(-y) ;
		printf("\n") ;
	}
}


int	stoss(int i)
/*
 * gives subatom's internal reference number from its external reference
 * number ( the one following [Ss] in the input file ). Returns 0
 * if the subatom is unknown.
 */
{
	int	j ;

	for (j = 1 ; j <= nass && sub[j].ss_ref != i ; j++) 
		;
	return (j > nass) ? 0 : j ;
}


