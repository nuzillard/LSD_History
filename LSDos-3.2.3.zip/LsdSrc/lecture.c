/*
    file: LsdSrc/lecture.c
    Copyright(C)2000 CNRS - FRE 2715 - Jean-Marc Nuzillard

    This file is part of LSD.

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "defs.h"

void	lecture(void) ;
void	remcomment(void) ;
void	lirecom(int ic) ;
void	lireliste(void) ;
void	non_nul(int errno, int v, ...) ;
int	z(char *noyau) ;
void	check_lecture(void) ;
void	check_list(int l)  ;
int	lnpos(void) ;

extern void	classe(int n, int t[]) ; /* lsd.c */
extern void	myexit(int i) ; /* lsd.c */

extern int	lnsize[MAX_LN] ;
extern int	ln[MAX_LN][MAX_LNBUF] ;
extern int	list[MAX_LIST][MAX_ATOMES] ;
extern FILE 	*fic1 ;
extern dynstring	*curstring ; /* lsd.c */
extern dyntext	*strtab ; /* lsd.c */

struct comtab coms[MAX_COM] = {
/*
 * field 1 : mnemonic
 * field 2 : number of arguments, -1 if it is a list (of unknown length)
 * field 3 : type of the arguments, see lirecom
 * field 4 : analysis priority order
 */
	{ "VALE", 3, "AIR", 0 }, /* 0 */
	{ "MULT", 4, "IAII", 1 }, /* 1 */
	{ "LIST", -1, "L", 2 }, /* 2 */
	{ "CARB", 1, "L", 2 }, /* 3 */
	{ "HETE", 1, "L", 2 }, /* 4 */
	{ "SP3 ", 1, "L", 2 }, /* 5 */
	{ "SP2 ", 1, "L", 2 }, /* 6 */
	{ "QUAT", 1, "L", 2 }, /* 7 */
	{ "CH  ", 1, "L", 2 }, /* 8 */
	{ "CH2 ", 1, "L", 2 }, /* 9 */
	{ "CH3 ", 1, "L", 2 }, /* 10 */
	{ "FULL", 1, "L", 2 }, /* 11 */
	{ "GREQ", 2, "LI", 2 }, /* 12 */
	{ "LEEQ", 2, "LI", 2 }, /* 13 */
	{ "GRTH", 2, "LI", 2 }, /* 14 */
	{ "LETH", 2, "LI", 2 }, /* 15 */
	{ "UNIO", 3, "BBL", 2 }, /* 16 */
	{ "INTE", 3, "BBL", 2 }, /* 17 */
	{ "DIFF", 3, "BBL", 2 }, /* 18 */
	{ "PROP", 3, "BIL", 3 }, /* 19 */
	{ "BOND", 2, "II", 4 }, /* 20 */
	{ "HMQC", 2, "II", 5 }, /* 21 */
	{ "COSY", 2, "II", 6 }, /* 22 */
	{ "HMBC", 2, "VI", 7 }, /* 23 */
	{ "ENTR", 1, "I", 0 }, /* 24 */
	{ "HIST", 1, "I", 0 }, /* 25 */
	{ "DISP", 1, "I", 0 }, /* 26 */
	{ "VERB", 1, "I", 0 }, /* 27 */
	{ "PART", 1, "I", 0 }, /* 28 */
	{ "STEP", 1, "I", 0 }, /* 29 */
	{ "WORK", 1, "I", 0 }, /* 30 */
	{ "MLEV", 1, "I", 0 }, /* 31 */
	{ "SSTR", 4, "SAVV", 8 }, /* 32 */
	{ "ASGN", 2, "SI", 9 }, /* 33 */
	{ "LINK", 2, "SS", 10 },  /* 34 */
	{ "DUPL", 1, "I", 0 }, /* 35 */
	{ "SUBS", 1, "T", 0 }, /* 36 */
	{ "ELIM", 2, "II", 0 }, /* 37 */
	{ "FILT", 1, "I", 0 }, /* 38 */
	{ "DEFF", 2, "FC", 11 }, /* 39 */
	{ "FEXP", 1, "C", 12 }, /* 40 */
	{ "CNTD", 1, "I", 0 } /* 41 */
/* 42 */
};


struct noy nucl[MAX_NUCL] = {
	{ "C", 4, 12.0, 0 },
	{ "N", 3, 14.0, 0 },
	{ "O", 2, 16.0, 0 },
	{ "X", 0, -1.0, 0 },
	{ "Y", 0, -1.0, 0 },
	{ "Z", 0, -1.0, 0 },
	{ "A", -1, 1.0, 0 }
};


struct crt cartes[MAX_CARTES] ;

float	reels[MAX_REELS] ;
int	ireels = 0 ;
float 	*preels = reels ;

int	lignes_lues ;
int	icarte ;
int	lnbuf[MAX_LNBUF] ;

int	ilnbuf ;
int	iln = 1;

void	lecture(void)
{
	char	c[5] ;
	int	ic, go, n ;

	lignes_lues = 0 ;
	icarte = 0 ;
	go = TRUE ;
	while (go) {
		remcomment() ;
/* removes comment(s) if any */
		go = !feof(fic1) ;
/* eof without an EXIT command should be possible */
		if (!go) {
			break ;
		}
		non_nul(100, fscanf(fic1, " %4[A-Z 23]", c)) ;
		non_nul(101, strlen(c) == 4, c) ;
/* read mnemonic */
		go = strcmp(c, "EXIT") ;
		if (!go) {
			break ;
		}
/* EXIT not encountered */
		lignes_lues++;
/* counts command lines */
		for (ic = 0 ; ic < MAX_COM && strcmp(coms[ic].op, c) ; ic++)
			;
		non_nul(102, MAX_COM - ic, c) ;
/* the mnemonic exists */
		lirecom(ic) ;
/* reads arguments following the mnemomic */
	}
	/*check_lecture() ; */
}


void	remcomment()
/*
 * a comment starts at a ; and ends up at the end of the line.
 */
{
	char	s[2] ;

	while (!feof(fic1) && fscanf(fic1, " %1[;]", s)) {
		while (!feof(fic1) && (getc(fic1)) != '\n') 
			;
	}
}


void	lirecom(int ic)
/* reads arguments of current command */
{
	int	i, nf, fl, v, h ;
	char	f, noyau[3], l[2] ;

	cartes[icarte].opnum = ic ;
	cartes[icarte].ln = lignes_lues ;
	nf = coms[ic].fields ;
/* expected arguments number */
	fl = nf < 0 ;
	if (fl) {
		nf = -nf ;
	}
/* special case of enumerated lists */
	for (i = 0 ; i < nf ; i++) {
		f = coms[ic].forme[i] ;
/* expecting argument of type f. its value will be stored in v */
		switch (f) {
		case 'A' :
/* symbol of atom requested */
			non_nul(110, fscanf(fic1, "%s", noyau)) ;
			v = z(noyau) ;
/* v is the nucleus number */
			break ;
		case 'B' :
/* either an atom index or [Ll]stuck with an integer
 * that is either an atom index or a logical list index */
			h = fscanf(fic1, " %1[Ll]", l) ;
/* h is true if it is a list index */
			non_nul(111, fscanf(fic1, "%d", &v)) ;
/* v is either an atom index or a list index */
			if (h) {
				non_nul(112, v < MAX_LIST, v, MAX_LIST-1) ;
				non_nul(115, v >= 0, v) ;
/* list indexes start at 0 */
				v = -v ; 
/* the list index is stored as its opposite */
			} else {
				non_nul(123, v > 0, v) ;
/* atom indexes are stored as themselves, start at 1 */
			}
			break ;
		case 'L' :
/* a list reference */
			non_nul(113, fscanf(fic1, " %1[Ll]", l)) ;
			non_nul(114, fscanf(fic1, "%d", &v)) ;
			non_nul(112, v < MAX_LIST, v, MAX_LIST-1) ;
			non_nul(115, v >= 0, v) ;
			break ;
		case 'I' :
/* an integer that is positive or zero */
			non_nul(116, fscanf(fic1, "%d", &v)) ;
			non_nul(124, v >= 0, v, i) ;
			break ;
		case 'T' :
/* an integer that can only be -1 0 1 */
			non_nul(116, fscanf(fic1, "%d", &v)) ;
			non_nul(128, v >= -1 && v <= 1, v, i) ;
			break ;
		case 'V' :
/* a numeric list or a single integer. a numeric list is enclosed 
 * between parentheses */
			h = fscanf(fic1, " %1[(]", l) ;
			if (h) {
/* this is a list */
				ilnbuf = 0 ;
/* index on numeric list buffer */
				do {
					non_nul(118, fscanf(fic1, "%d", &v)) ;
					lnbuf[ilnbuf++] = v ;
					non_nul(125, v >= 0, v) ;

/* put integer into the buffer */
				} while ((!fscanf(fic1, " %1[)]", l)) && (ilnbuf < MAX_LNBUF)) ;
/* while no ) is encountered */
				non_nul(119, MAX_LNBUF - ilnbuf, MAX_LNBUF) ;
				v = -lnpos() ;
/* lnpos stores the content of the buffer to its definive location
 * lnpos returns the numeric list number, stored as its opposite */
			} else {
				non_nul(120, fscanf(fic1, "%d", &v)) ;
				non_nul(124, v >= 0, v, i) ;
			}
/* single integer */
			break ;
		case 'S' :
/* subatome reference, starts with [Ss] */
			non_nul(121, fscanf(fic1, " %1[Ss]", l)) ;
			non_nul(122, fscanf(fic1, "%d", &v)) ;
/* range checking for v is achieved in sub.c */
			break ;
		case 'R' :
/* read an optional real number, either atom mass or chemical shift */
			if (fscanf(fic1, "%f", preels)) {
				v = ireels ;
				preels++ ;
				ireels++ ;
				non_nul(145, MAX_REELS - ireels, MAX_REELS) ;
			} else {
				v = -1 ;
			}
			break ;
		case 'F' :
/* fragment (substructure) reference, starts with [Ff] */
			non_nul(150, fscanf(fic1, " %1[Ff]", l)) ;
			non_nul(151, fscanf(fic1, "%d", &v)) ;
			non_nul(152, v > 0, v) ;
			break ;
		case 'C' :
/* character string */
			non_nul(160, fscanf(fic1, " %1[\"]", l)) ;
			dynstring_reset(curstring) ;
			while(!feof(fic1) && (h = fgetc(fic1)) != '\"') {
				dynstring_pushc(curstring, h) ;
			}
			non_nul(161, h == '\"') ;
			v = dyntext_push(strtab, curstring, 0, NULL) ;
			non_nul(162, v >= 0) ;
		}
		cartes[icarte].pars[i] = v ;
/* v is stored */
	}
	if (fl) {
/* there is still the content of the list to read */
		lireliste() ;
	}
	icarte++;
/* next command */
	non_nul(117, MAX_CARTES - icarte, MAX_CARTES) ;
}


int	lnpos(void)
{
	int	i, j ;

	classe(ilnbuf, lnbuf) ;
/* ordering numeric values in lnbuf */
	for(j = 0 ; j < ilnbuf-1 && lnbuf[j] != lnbuf[j+1] ; j++)
		;
	non_nul(140, j == ilnbuf-1, lnbuf[j]) ;
/* searching for duplicated values */
	for (i = 1 ; i < iln ; i++) {
/* looking for the equality of lnbuf and a previously entered list */
/* remember that iln starts at 1 */
		if (ilnbuf != lnsize[i]) {
			continue ;
/* they do not have the same number of elements */
		}
		for (j = 0 ; j < ilnbuf && lnbuf[j] == ln[i][j] ; j++) 
			;
		if (j == ilnbuf) {
			return i ;
/* ln[i] is identical to lnbuf, return i */
		}
	}
	for (j = 0 ; j < ilnbuf ; j++) 
		ln[iln][j] = lnbuf[j] ;
	lnsize[iln] = ilnbuf ;
/* stores lnbuf as ln[iln] and stores its size */
	i = iln++;
/* next list */
	non_nul(141, MAX_LN - iln, MAX_LN-1) ;
	return i ;
}


void	lireliste(void)
{
	int	i, il, a ;

	il = cartes[icarte].pars[0] ;
	for (i = 0 ; i < MAX_ATOMES ; i++) {
		list[il][i] = FALSE ;
	}
/* resets the list */
	while (fscanf(fic1, "%d", &a)) {
		non_nul(126, a < MAX_ATOMES, a, MAX_ATOMES-1) ;
		non_nul(127, a > 0, a) ;
		list[il][a] = TRUE ;
/* reads the list */
	}
}


void	non_nul(int errno, int v, ...)
/* 
 * prints a message if the value v is 0 
 */
{
#define MAX_MSG 89
	va_list l ;
	int	i ;
	static struct msg {
		int	errco ;
		char	*errmsg ;
	} msgs[MAX_MSG] = {
		{ 100, "Bad first character in command name." },
		{ 101, "Bad character in command name. "
"Reading stopped after \"%s\"." },
		{ 102, "Unknown command name: %s" },
		{ 110, "Cannot read atom symbol." },
		{ 111, "Cannot read atom or atom list index." },
		{ 112, "List index %d is too high.\n"
"Maximum list index is %d.\n"
"Try with a lower list index or recompile with a higher MAX_LIST." },
		{ 115, "List index cannot be negative (is %d)." },
		{ 113, "L expected." },
		{ 114, "Cannot read list index." },
		{ 123, "Atom indexes start at 1 (is %d)." },
		{ 116, "Cannot read integer value." },
		{ 124, "Integer value cannot be negative (is %d) field %d." },
		{ 118, "Cannot read integer value in a (...) list." },
		{ 125, "Value in a (...) list cannot be negative (is %d)." },
		{ 119, "The size of a (...) list is limited to %d elements.\n"
"Carefully consider recompiling with a higher MAX_LNBUF." },
		{ 120, "Cannot read integer value." },
		{ 117, "The number of commands is limited to %d.\n"
"Recompile with a higher MAX_CARTES." },
		{ 121, "A sub-structure atom reference starts with \"S\"." },
		{ 122, "Cannot read sub-structure atom index after \"S\"." },
		{ 140, "Duplicated value (is %d) in a (...) list." },
		{ 141, "The number of (...) lists is limited to %d.\n"
"Carefully consider recompiling with a higher MAX_LN." },
		{ 126, "Atom index %d is higher than the allowed maximum (%d)." },
		{ 127, "Atom indexes start at 1 (is %d)." },
		{ 128, "Integer value should be -1, 0, or 1 (is %d)." },
		{ 131, "Unknown atom symbol: %s." },
		{ 145, "The number of real values is limited to %d.\n"
"Recompile with a higher MAX_REELS." },
		{ 150, "F expected." },
		{ 151, "Cannot read fragment (sub-structure) index after F." },
		{ 152, "Fragment (sub-structure) indexes start at 1 (is %d)." },
		{ 160, "A string must start with a \"." },
		{ 161, "End Of File was reached during string reading." },
		{ 162, "Memory allocation error.\n"
"Cannot store new string." },
		{ 200, "Valence of \"%s\" is already defined (is %d)." },
		{ 201, "Valence of \"%s\" cannot be 0." },
		{ 202, "Valence of \"%s\" cannot be grater than %d (is %d).\n"
"Recompile with a higher MAX_NLIA." },
		{ 203, "Mass of \"%s\" cannot be less than 1.0 (is %.5f)." },
		{ 210, "Atom index cannot be 0." },
		{ 211, "The atom indexes are limited to %d (is %d).\n"
"Recompile with a higher MAX_ATOMES." },
		{ 212, "Hybridization state of atom %d is %d.\n"
"It must be is either 2 or 3 for sp2 and sp3 atoms." },
		{ 213, "The valence of atom %d has not been defined." },
		{ 214, "Atom %d cannot be of valence %d, be sp%d hybridized, "
"and be bonded to %d hydrogen atoms." },
		{ 260, "Atom %d is undefined but in list L%d." },
		{ 261, "List L%d cannot be empty." },
		{ 270, "Cannot define property of unknown atom %d." },
		{ 271, "Cannot define property of atoms in unknown list L%d." },
		{ 230, "Cannot set an HMQC correlation of atom %d with H-%d "
"because atom %d is not defined by a MULT command." },
		{ 231, "Cannot set an HMQC correlation of atom %d with H-%d "
"because hydrogen atom indexes start at 1."},
		{ 232, "Cannot set an HMQC correlation of atom %d with H-%d "
"because the atom indexes are limited to %d.\n"
"Recompile with a higher MAX_ATOMES." },
		{ 233, "Cannot set an HMQC correlation of atom %d with H-%d "
"because atom %d already correlates with H-%d and H-%d." },
		{ 234, "Cannot set an HMQC correlation of atom %d with H-%d "
"because atom %d already correlates with H-%d." },
		{ 235, "Cannot set an HMQC correlation of atom %d with H-%d "
"because atom %d already correlates with H-%d and does not belong to a "
"%sH2 group." },
		{ 240, "Cannot set a COSY correlation between H-%d and H-%d "
"because H-%d is not defined by an HMQC command." },
		{ 250, "Cannot set an HMBC correlation between %d and H-%d "
"because H-%d is not defined by an HMQC command." },
		{ 251, "Cannot set an HMBC correlation between %d and H-%d "
"because atom %d is not defined by a MULT command." },
		{ 280, "Attempting to bind atoms %d and %d but %d is not defined." },
		{ 282, "Attempting to bind already bonded atoms %d and %d." },
		{ 283, "Attempting to bind atoms %d and %d but %d has already "
"reached the maximum number of neighbors (is %d)." },
		{ 320, "Attempting to use the undefined atom %d in a list "
"construction command." },
		{ 321, "Attempting to use the undefined atom list L%d in a list "
"construction command." },
		{ 330, "The maximum number of property lists of atom %d "
"is %d.\nRecompile with a higher MAX_NLPR." },
		{ 331, "The property list L%d of atom %d causes it to have "
"%d neighbors in property lists whilst it only has %d neighbors." },
		{ 332, "The property list L%d of atom %d contains atom %d "
"that also belongs to L%d.\nProperty lists of an atom cannot overlap." },
		{ 340, "Cannot bind atoms %d and %d.\n"
"Property list violation of atom %d, from either a BOND or a COSY command." },
		{ 350, "Sub-atom indexes start at 1 (is %d)." },
		{ 351, "Attempting to redefine sub-atom S%d." },
		{ 352, "Sub-atom indexes are limted to %d.\n"
"Recompile with a higher MAX_NASS." },
		{ 353, "Hybridization state of sub-atom S%d can only be "
"sp2 or sp3 (is sp%d)." },
		{ 354, "Bad multiplicity of sub-atom S%d (is %d)." },
		{ 360, "Sub-atom S%d is not defined by a SSTR command." },
		{ 361, "Cannot identify sub-atom S%d to unknown atom %d." },
		{ 362, "Cannot identify sub-atom S%d to atom %d "
"because it is already identified to atom %d." },
		{ 370, "Too many bonds in sub-structure.\n"
"Recompile with a higher MAX_NSSL." },
		{ 371, "Attempting to bind sub-atoms S%d and S%d "
"but S%d is not defined by a SSTR command." },
		{ 372, "Attempting to bind sub-atoms S%d and S%d "
"but S%d has too many (is %d) bonds.\nRecompile with a higher MAX_NLIA." },
		{ 380, "Number of bonds in ELIM must be either 0 (no limit) "
"or strictly greater than 3 (is %d)." },
		{ 390, "Odd number of sp2 atoms (is %d)." },
		{ 391, "Odd total sum of valences (is %d)." },
		{ 400, "Attempting to redefine fragment F%d." },
		{ 401, "Cannot open file %s that defines fragment F%d." },
		{ 402, "FEXP: Attempting to redefine the filter expression." },
		{ 403, "FEXP: Cannot open expression file: %s." },
		{ 404, "FEXP: Internal error.\n"
"failed to create the logical expression compiler." },
		{ 405, "FEXP: Failed to compile the logical expression: \"%s\"" },
		{ 406, "FEXP: F%d is an unknown fragment." },
		{ 410, "Invalid command in this fragment file: %s." },
		{ 420, "Attempting to bind atoms %d and %d leads to "
"non-connected solutions.\nAdd a \"CNTD 0\" command if this is what is wanted." },
		{ 500, "Internal error.\n"
"Cannot create string buffer." },
		{ 501, "Internal error.\n"
"Cannot create text buffer." },
		{ 502, "Internal error.\n"
"Cannot store native substructure." }
	};


	if (v) {
		return ;
/* nothing to do */
	}
	
	printf("error %d - %d commands read\n", errno, lignes_lues) ;
	for (i = 0 ; i < MAX_MSG && msgs[i].errco != errno ; i++) 
		;
	if (i != MAX_MSG) {
		va_start(l, v) ;
		vprintf(msgs[i].errmsg, l) ;
		va_end(l) ;
		printf("\n") ;
/* prints the message */
	} else {
		printf("unknown error !!!!\n") ;
/* should not happen */
	}
	check_lecture() ;
	myexit(-1) ;
}


int	z(char *noyau)
/* 
 * looks up in the nucl table in order to get the nucleus reference 
 */
{
	int	i ;

	for (i = 0 ; (i < MAX_NUCL) && strcmp(noyau, nucl[i].sym) ; i++)  
		;
	non_nul(131, MAX_NUCL - i, noyau) ;
	return i ;
}


void	check_lecture(void)
/* lists for each read command the command number,
 * the mnemonic, the arguments as the v values determined in lirecom */
{
	int	i, j, o, n, fl ;

	for (i = 0 ; i < icarte ; i++) {
		o = cartes[i].opnum ;
		n = coms[o].fields ;
		fl = n < 0 ;
/* for the LIST command */
		if (fl) {
			n = -n ;
		}
		printf("%4d : %4s  ", i + 1, coms[o].op) ;
		for (j = 0 ; j < n ; j++) {
			printf("%4d", cartes[i].pars[j]) ;
		}
		if (fl) {
			check_list(cartes[i].pars[0]) ;
		}
		printf("\n") ;
	}
/* could be done in a better way, but would be more expensive */
}


void	check_list(int l)
/*
 * displays a (logical) list 
 */
{
	int	i ;

	for (i = 0 ; i < MAX_ATOMES ; i++) {
		if (list[l][i]) {
			printf("%3d", i) ;
		}
	}
}


