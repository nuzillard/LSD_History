/*
    file: LsdSrc/lecture.c
    Copyright(C)2000 CNRS - FRE 2715 - Jean-Marc Nuzillard

    This file is part of LSD.

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "defs.h"
#include <stdio.h>

extern struct atom at[MAX_ATOMES] ; /* lsd.c */
extern struct noy nucl[MAX_NUCL] ; /* lecture.c */
extern int numdbbonds ; /* doubles.c */

int chklsd(void) ;

int chklsd(void)
{
	int numatomes = 0 ;
	int numbonds = 0 ;
	float curmass ;
	float totalmass = 0 ;
	int numinsat ;
	int numrings ;
	int nH ;
	int skelbonds ;
	int badmass = FALSE ;
	int i ;
	int n ;
	
	numdbbonds /= 2 ;
/* numdbbonds was previously the number of sp2 atoms, it must be an even number */
	for (i = 0 ; i < (MAX_NUCL-1) ; i++) {
		numbonds += nucl[i].val * nucl[i].count ;
	}
	numbonds += nucl[i].count ;
	if ((numbonds % 2) == 1) return FALSE ;
	numbonds /= 2 ;
	for (i = 0 ; i < MAX_NUCL ; i++) {
		n = nucl[i].count ;
		if (n > 0) {
			numatomes += n ;
			curmass = nucl[i].mass ;
			if (curmass < 0.0) {
				badmass = TRUE ;
				printf("Mass of %s is unknown\n", nucl[i].sym) ;
			} else {
				totalmass += n * curmass ;
			}
		}
	}
	numinsat = numbonds - numatomes + 1 ;
	numrings = numinsat - numdbbonds ;
	nH = nucl[MAX_NUCL-1].count ;
	skelbonds = numbonds - numdbbonds - nH ;
	for (i = 0 ; i < (MAX_NUCL-1) ; i++) {
		n = nucl[i].count ;
		if (n > 0) {
			printf("%s%d ", nucl[i].sym, n) ;
		}
	}
	printf("H%d ", nH) ;
	printf("\n") ;
	printf("%d atom%s\n", numatomes, (numatomes > 1) ? "s" : "") ;
	printf("%d bond%s\n", numbonds, (numbonds > 1) ? "s" : "") ;
	printf("%d double bond%s\n", numdbbonds, (numdbbonds > 1) ? "s" : "") ;
	printf("%d skeletal bond%s\n", skelbonds, (skelbonds > 1) ? "s" : "") ;
	printf("%d ring%s\n", numrings, (numrings > 1) ? "s" : "") ;
	if (!badmass) {
		printf("M = %.5f\n", totalmass) ;
	}
	return TRUE ;
}
