/*
    file: LsdSrc/sub.c
    Copyright(C)2000 CNRS - UMR 6013 - Jean-Marc Nuzillard

    This file is part of LSD.

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "defs.h"
#include <stdio.h>

extern int	flverb ; /* lsd.c */
extern int	flsubs ; /* lsd.c */
extern struct atom at[MAX_ATOMES] ; /* lsd.c */
extern int	max_atomes ; /* lsd.c */
extern int	lnsize[MAX_LN] ; /* lsd.c */
extern int	ln[MAX_LN][MAX_LNBUF] ; /* lsd.c */

extern void	marque(void) ; /* lsd.c */
extern void	empile(int t, int a, int v) ; /* lsd.c */
extern void	relache(void) ; /* lsd.c */
extern int	ok(void) ; /* lsd.c */
extern int	estlie(int x, int y) ; /* start.c */

struct ss_atom sub[MAX_ATOMES] ; /* sub atoms storage */
int	nssl = 0 ; /* number of bonds in the substructure - see main */
int	nass = 0 ; /* number of subatoms */
int	s1[MAX_NSSL] ; /* ordered subbonds starting point */
int	s2[MAX_NSSL] ; /* ordered subbonds ending point */
int	ss_ok ; /* true if the substructure has been found in the structure */

int	init_sstr(void) ;
int	critere(int x, int ssx) ;
int	crit_e(int x, int ssx) ;
int	crit_h(int x, int ssx) ;
int	crit_m(int x, int ssx) ;
int	attribuer(void) ;
void	attrib(int i) ;
void	criter2(int i, int y, int ssy) ;

int	init_sstr(void)
/*
 * defines the strategy for subatoms assignment. The subbonds are reordered
 * so that the substructure will be exploited in order to built a 
 * connexe group of subatoms (when possible). s1[i] gives the start
 * of the ith subbond and s2[i] gives its end. s2[i] will be assigned according
 * the assignment of s[i]. If s1[i] is zero there is no preceeding
 * assignment to rely on. s2[j] is the current starting subatom.
 */
{
	int	i, j, k, x, y, ilss, e ;

	if (!flsubs) {
		return 0 ;
	}
/* substructure search is disabled : nothing to do */
	if (!nass) {
		return 0 ;
	}
/* no subatom : nothing to do */
	ilss = nssl ;
/* nssl is the number of subbonds */
	i = j = 0 ;
	while (ilss) {
/* as long as there are subbonds */
		if (i == j) {
/* cold start */
			for (x = 1 ; (x <= nass) && !( sub[x].ss_asgn && !sub[x].ss_init) ; x++) 
				;
/* x is assigned but still not used */
			if (x > nass) {
/* no x available */
				for (x = 1 ; (x <= nass) && sub[x].ss_init ; x++) 
					;
/* x is not used */
			}
			s1[i] = 0 ;
			s2[i] = x ;
			sub[x].ss_init = 1 ;
			i++;
/* x is now used. subbond 0-x stored */
		} else {
			x = s2[j] ;
			if (sub[x].ss_init == 1) {
/* x is an ending point that can be used as a new starting point */
				for (k = 0 ; k < sub[x].ss_nlia ; k++) {
					y = sub[x].ss_lia[k] ;
					e = sub[y].ss_init ;
/* y is the kth subneighbour of x. Its state is e */
					if (e != 2) {
/* y has never been used as starting point */
						s1[i] = x ;
						s2[i] = y ;
						i++;
						ilss--;
/* the bond x-y is now stored */
						if (!e) {
							sub[y].ss_init = 1 ;
/* if y has never been an ending point, it becomes an ending point */
						}
					}
				}
				sub[x].ss_init = 2 ;
/* x has been used as a starting point */
			}
			j++;
/* ready for the next starting point */
		}
	}
	if (flverb) {
/* listing of the order of the attributions */
		printf("assignment order\nx : ") ;
		for (j = 0 ; j < i ; j++) {
			printf("%4d", sub[s1[j]].ss_ref) ;
		}
		printf("\n") ;
		printf("y : ") ;
		for (j = 0 ; j < i ; j++) {
			printf("%4d", sub[s2[j]].ss_ref) ;
		}
		printf("\n") ;
	}
	return i ;
/* returns the number of recursive steps in the attribution process */
}


int	critere(int x, int ssx)
/*
 * checks the compatibility between the atom x and the subatom ssx
 */
{
	return crit_e(x, ssx) &&  crit_h(x, ssx) &&  crit_m(x, ssx) ;
}


int	crit_e(int x, int ssx)
/* 
 *checks the identity of elements
 */
{
	return at[x].element == sub[ssx].ss_element ;
}


int	crit_h(int x, int ssx)
/* 
 *checks the compatibility of the hybridization states 
 */
{
	int	i, h, s ;

	h = sub[ssx].ss_hybrid ;
	if (h >= 0)
		return h == 3 - at[x].hybrid ;
	else {
		for (i = 0 ; i < (s = lnsize[-h]) &&  ln[-h][i] != 3 - at[x].hybrid ; i++) 
			;
		return i != s ;
	}
}

int	crit_m(int x, int ssx)
/* 
 *checks the compatibility of the multiplicities 
 */
{
	int	i, m, s ;

	m = sub[ssx].ss_mult ;
	if (m >= 0)
		return m == at[x].mult ;
	else {
		for (i = 0 ; i < (s = lnsize[-m]) &&  ln[-m][i] != at[x].mult ; i++) 
			;
		return i != s ;
	}
}

int	attribuer(void)
/*
 * top level of the recursive assignment process
 */
{
        if(!flsubs) {
                ss_ok = TRUE ;
        } else {
                ss_ok = FALSE ;
	        attrib(0) ;
        }
        return ss_ok ;
}


void	attrib(int i)
/*
 * assignment of the substructure. nssl is now the number of assignment
 * steps (see main).
 */
{
	int	x, y, ssx, ssy, j ;

	if (i == nssl) {
		ss_ok = TRUE ;
		return ;
/* end condition of recursivity. if this point is reached the substructure
 * is fully assigned. That means it is present in the structure */
	}
	ssx = s1[i] ;
	ssy = s2[i] ;
	y = sub[ssy].ss_asgn ;
	if (ssx) {
		x = sub[ssx].ss_asgn ;
/* the starting subatom ssx is already assigned to x */
		if (y) {
/* if y is already assigned, too */
			if (estlie(x, y)) {
				attrib(i + 1) ;
/* and if x and y are bound, everything is ok. goes on. */
			} else {
				return ;
/* something is wrong somewhere. goes back. */
			}
		} else {
			for (j = 0 ; j < at[x].nlia ; j++) {
/* x <--> ssx. ssx is bound to ssy. therefore if y <--> ssy, x and y
 * have to be bound. y is x's jth neighbour. */
				y = at[x].lia[j] ;
				criter2(i, y, ssy) ;
/* checks if y and ssy have compatible status and call attrib at the next level.
   performs then the actual assignment job */
				if (ss_ok) {
					break ;
/* once all the assignments done there is no need to look for an other
 * possible assignments set. Assignment are never used in the solution output */ 
				}
			}
		}
	} else {
/* ssy is assigned from scratch */
		if (y) {
			attrib(i + 1) ;
/* if ssy is already assigned there is nothing to do */
		} else {
			for (y = 1 ; y <= max_atomes ; y++) {
				if (!at[y].utile) {
					continue ;
				}
				criter2(i, y, ssy) ;
/* checks if y and ssy have compatible status and call attrib at the next level.
   performs then the actual assignment job */
				if (ss_ok) {
					break ;
				}
			}
		}
	}
}


void	criter2(int i, int y, int ssy)
{
	if ((!at[y].asgn) && critere(y, ssy)) {
/* ssy has never been assigned, therefore y cannot be already assined.
 * y and ssy must be compatible */
		if (flverb) 
			printf("assigns S%d to %d\n", sub[ssy].ss_ref, y) ;
		if (ok()) {
			marque () ;
			empile(0, (int)&sub[ssy].ss_asgn, y) ;
			empile(0, (int)&at[y].asgn, ssy) ;
			attrib(i + 1) ;
			relache() ;
/* updates assignement information, to be released after backtracking */
		}
	}
}


