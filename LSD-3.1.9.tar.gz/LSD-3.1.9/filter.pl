#!/usr/bin/perl
#    file: filter.pl
#    Copyright (C) 2000 CNRS, FRE 2715, Jean-Marc Nuzillard.
#
#    This file is part of LSD.
#
#    LSD is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    LSD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with LSD; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

use Filters::bin::SolnFilter ;

my $f = new SolnFilter ;

if($#ARGV == 0) {
# 1 argument on the command line, the name of the filter script file
	$f->read($ARGV[0]) ;
} else {
# 0 argument ($#ARGV is -1), use filter.dat as filter script file
	$f->read() ;
}
unless ($f->ok()) {
# filter initialization failed
	print $f->msg() . "\n" ;
	exit(1) ;
}
# does the job
$f->chkAllSolutions() ;
unless ($f->ok()) {
# an error has occured during solution processing
	print "Error :" ;
	print $f->msg() . "\n" ;
} else {
# prints statistics
	print "Kept: " ;
	print $f->nkept() ;
	print " Rejected: " ;
	print $f->nrejected() ;
	print "\n" ;
}
# normal exit
exit(0) ;




