/*
    file: LsdSrc/sub.c
    Copyright(C)2000 CNRS - FRE 2715 - Jean-Marc Nuzillard

    This file is part of LSD.

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "defs.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

extern int	flverb ; /* lsd.c */
extern int	flsubsgood ; /* lsd.c */
extern int	flsubsbad ; /* lsd.c */
extern struct atom 	at[MAX_ATOMES] ; /* lsd.c */
extern int	max_atomes ; /* lsd.c */
extern int	lnsize[MAX_LN] ; /* lsd.c */
extern int	ln[MAX_LN][MAX_LNBUF] ; /* lsd.c */
extern dynstring	*curstring ; /* lsd.c */
extern dyntext	*strtab ; /* lsd.c */
extern FILE	*fic1 ; /* lsd.c */
extern int	flclose ; /* lsd.c */
extern int	fldeff ; /* lsd.c */
extern int	flfexp ; /* lsd.c */
extern int	flnative ; /* lsd.c */
extern struct noy 	nucl[MAX_NUCL] ; /* lecture.c */
extern struct comtab 	coms[MAX_COM] ; /* lecture.c */
extern struct crt 	cartes[MAX_CARTES] ; /* lecture.c */
extern int	icarte ; /* lecture.c */
extern int	lignes_lues ; /* lecture.c */

extern void	marque(void) ; /* heap.c */
extern void	empile0(int *a, int v) ; /* heap.c */
extern void	empile(int t, int a, int v) ; /* heap.c */
extern void	relache(void) ; /* heap.c */
extern int	ok(void) ; /* lsd.c */
extern int	estlie(int x, int y) ; /* start.c */
extern void	lecture(void) ; /* lecture.c */
extern void	non_nul(int errno, int v) ; /* lecture.c */
extern void	wrln2(int y) ; /* start.c */

struct ss_atom 	sub[MAX_ATOMES] ; /* sub atoms storage */
int	nssl = 0 ; /* number of bonds in the substructure - see main */
int	nass = 0 ; /* number of subatoms */
int	s1[MAX_NSSL] ; /* ordered subbonds starting point */
int	s2[MAX_NSSL] ; /* ordered subbonds ending point */
int	ss_ok ; /* true if the substructure has been found in the structure */

void	native_sstr(void) ;
int	test_open_deff(int p) ;
int	test_open_fexp(int p) ;
void	readfragments(void) ;
int	*readfragment(int f, char *filename) ;
void	sub_start(void) ;
void 	sub_start1(int ic) ;
void	unused_fragments(int n) ;
int	init_sstr(int f) ;
int	print_sub_index(int f) ;
int	*serialize() ;
int	critere(int x, int ssx) ;
int	crit_e(int x, int ssx) ;
int	crit_h(int x, int ssx) ;
int	crit_m(int x, int ssx) ;
int	attribuer(void) ;
int	fragment(int f) ;
void	explode(int f) ;
void	reset_atom_asgn(void) ;
void	attrib(int i) ;
void	criter2(int i, int y, int ssy) ;
void	sub_about(void) ;
void	sub_about2(int f, char *s) ;


void	native_sstr(void)
/*
 * stores native substructure information so that it will be possible
 * to refer to it as F0 (fragment 0) in a complexe substructure search.
 * The native substructure is the one that is not defined by a
 * DEFF command.
 */
{
	int n ;
	int *data ;

	nssl = init_sstr(0) ;
	flnative = (nass > 0) ? 1 : 0 ;
	dynstring_reset(curstring) ;
	n = dynstring_pushs(curstring, "NATIVE") ;
	non_nul(502, n) ;
	data = serialize() ;
	non_nul(503, data != NULL) ;
	n = dyntext_push(strtab, curstring, 0, data) ;
	non_nul(504, n >= 0) ;
}


int	test_open_deff(int p)
/* returns 1 if succeeds to open file whose name is at line p in strtab
and 0 otherwise */
{
	char *filename ;
	FILE *test ;
	
	filename = dyntext_getstr(strtab, p) ;
	if((test = fopen(filename, "r")) == NULL){
		return 401 ;
	}
	fclose(test) ;
	return 0 ;
}


int	test_open_fexp(int p)
/* formats the expression string, either from LSD input file
 * or from external file, initializes the expression compiler,
 * checks if the fragments are defined. Returns 0 if everything
 * is fine or the error number, otherwise
 */
{
	char *exprinfo, *expr, *filename ;
	FILE *in ;
	char c, *pc ;
	plvm logic ;
	int fragc, *fragv, i ;

	exprinfo = dyntext_getstr(strtab, p) ;
/* exprinfo may either directly be a logical expression
or the name of a file that contains it */
	if(exprinfo[0] == '>') {
		filename = exprinfo + 1 ;
/* the file name starts immediately after the > sign */
		if((in = fopen(filename, "r")) != NULL){
			dynstring_reset(curstring) ;
/* the actual expression will be stored in curstring */
			while(!feof(in)) {
				dynstring_pushc(curstring, fgetc(in)) ;
			}
			fclose(in) ;
			expr = dynstring_getstring(curstring) ;
/* expression in expr is the string field of curstring */
		} else {
			return 403 ;
/* error code if file opening fails */
		}
	} else {
		expr = exprinfo ;
/* expression in expr is directly the one in strtab at line p */ 
	}
	for(pc = expr ; c = *pc ; pc++) {
		if(isspace(c)) {
			*pc = ' ' ;
		}
		if(islower(c)) {
			*pc = toupper(c) ;
		}
	}
/* changes all spaces to blanks and lowercase to uppercase
for the lvm compiler. This operation does not change the length
of the string and may therefore be carried out in-place. */
	if(expr != exprinfo) {
		dyntext_setstr(strtab, p, expr) ;
/* this is not strictly speaking useful but may be, one day, a many
expression LSD input file will be implemented, so it's better to keep
the expression from external file in strtab */
	}
	logic = lvm_new(expr) ;
	if(logic == NULL) {
		return 404 ;
	}
	if(lvm_error(logic)) {
		return 405 ;
	}
	lvm_vars(logic, &fragc, &fragv) ;
	for(i=0 ; i<fragc ; i++) {
		if(!dyntext_index_exists(strtab, fragv[i])) {
			return 406 ;
		}
	}
	flfexp = fragc ;
	dyntext_setserial(strtab, p, (int *)logic) ;
/* I know, this is not elegant */
	dyntext_setindex(strtab, p, -1) ;
	return 0 ;
}


void	readfragments(void)
/* processes non-native fragment files */
{
	int i, l, f ;
	char *filename ;

	if(flclose) {
		fclose(fic1) ;
		fic1 = NULL ;
	}
/* closes the main input file so that fragment files can be read.
Setting fic1 to NULL avoids re-closing this file in myexit(). */
	l = dyntext_getlength(strtab) ;
	for(i=0 ; i<l ; i++) {
		f = dyntext_getindex(strtab, i) ;
		if(f > 0) {
			filename = dyntext_getstr(strtab, i) ;
			dyntext_setserial(strtab, i, readfragment(f, filename)) ;
		}
	}
	unused_fragments((flfexp == 0) ? fldeff : fldeff + flnative - flfexp) ;
}


int	*readfragment(int f, char *filename)
/* returns serialized sub-structure from file whose name is filename */
{
	fprintf(stderr, "Reading fragment file: %s\n", filename) ;
	fic1 = fopen(filename, "r") ;
/* should not fail because it was already tested in test_open_diff */
	lecture() ;
/* reads commands from fragment file */
	fclose(fic1) ;
	fic1 = NULL ;
/* no need any more for this input file */
	sub_start() ;
/* decodes commands from fragment file */
	nssl = init_sstr(f) ;
/* builds fragment assignment strategy */
	return serialize() ;
}


void	sub_start(void)
/* 
 * decodes commands from fragment file. This is a simplified copy
 * of start() in start.c
 */
{
	int ic, ip ;
	char *o ;
	
	nass = 0 ;
	nssl = 0 ;
	reset_atom_asgn() ;
/* resets substructure information */
	for (ic = 0 ; ic < icarte ; ic++) {
		o = coms[cartes[ic].opnum].op ;
		non_nul(505, !(
			strcmp(o, "SSTR") && 
			strcmp(o, "LINK") && 
			strcmp(o, "ASGN"))) ;
	}
/* checks for substructure-only commands */
	for (ip = 8 ; ip <= 10 ; ip++) {
/* analyzing commands following ascending priority order,
8 is priority for SSTR, 9 for ASGN, 10 for LINK */
		for (ic = 0 ; ic < icarte ; ic++) {
			if (coms[cartes[ic].opnum].prior == ip) {
/* printf("# %d priority %d command %s\n", ic+1, ip, coms[cartes[ic].opnum].op) ; */
				lignes_lues = cartes[ic].ln ;
				sub_start1(ic) ;
			}
		}
	}
}


void 	sub_start1(int ic)
{
	int o, p1, p2, p3, p4, *pp ;
	struct crt *pcrt ;
	int i, j ;
	
	pcrt = &(cartes[ic]) ;
	o = pcrt->opnum ;
	pp = pcrt->pars ;
	p1 = pp[0] ;
	p2 = pp[1] ;
	p3 = pp[2] ;
	p4 = pp[3] ;
	switch (o) {
	case 32 : /* SSTR : substructure S A V V */
		non_nul(350, p1 > 0) ;
		non_nul(351, !stoss(p1)) ;
/* p1 is a new subatom reference */
		nass++;
		non_nul(352, nass < MAX_NASS) ;
		sub[nass].ss_ref = p1 ;
		sub[nass].ss_element = p2 ;
		sub[nass].ss_hybrid = p3 ;
		if (p3 > 0) 
			non_nul(353, (p3 == 2) || (p3 == 3)) ;
		else 
			for (i = 0 ; i < lnsize[-p3] ; i++) {
				j = ln[-p3][i] ;
				non_nul(353, (j == 2) || (j == 3)) ;
			}
		sub[nass].ss_mult = p4 ;
		if (p4 >= 0) 
			non_nul(354, (p4 >= 0) && (p4 <= 3)) ;
		else 
			for (i = 0 ; i < lnsize[-p4] ; i++) {
				j = ln[-p4][i] ;
				non_nul(354, (j >= 0) && (j <= 3)) ;
			}
		sub[nass].ss_nlia = 0 ;
		sub[nass].ss_asgn = 0 ;
		sub[nass].ss_init = 0 ;
/* defines a subatom */
		break ;
	case 33 : /* ASGN : assign S I */
		i = stoss(p1) ;
		non_nul(360, i) ;
		non_nul(361, (p2 > 0) && (p2 < max_atomes) && (at[p2].utile)) ;
		non_nul(362, !sub[i].ss_asgn) ;
		sub[i].ss_asgn = p2 ;
		at[p2].asgn = i ;
/* updates substructure assignment information */
		break ;
	case 34 : /* LINK : link S S */
		non_nul(370, nssl < MAX_NSSL) ;
		i = stoss(p1) ;
		j = stoss(p2) ;
		non_nul(371, i) ;
		non_nul(373, sub[i].ss_nlia < 4) ;
		non_nul(372, j) ;
		non_nul(374, sub[j].ss_nlia < 4) ;
		sub[i].ss_lia[sub[i].ss_nlia++] = j ;
		sub[j].ss_lia[sub[j].ss_nlia++] = i ;
		nssl++;
/* set bonds between subatoms - validations could be improved */
		break ;
	}
}

void	unused_fragments(int n)
{
	if(n > 1) {
		fprintf(stderr, "Warning: there are unused fragments\n") ;
	}
	if(n == 1) {
		fprintf(stderr, "Warning: there is an unused fragment\n") ;
	}
}


int	init_sstr(int f)
/*
 * defines the strategy for subatoms assignment. The subbonds are reordered
 * so that the substructure will be exploited in order to built a
 * connexe group of subatoms (when possible). s1[i] gives the start
 * of the ith subbond and s2[i] gives its end. s2[i] will be assigned according
 * to the assignment of s1[i]. If s1[i] is zero there is no preceeding
 * assignment to rely on. s2[j] is then the current starting subatom.
 */
{
	int	i, j, k, x, y, ilss, e ;

	if (!nass) {
		return 0 ;
	}
/* no subatom : nothing to do */
	ilss = nssl ;
/* nssl is the number of subbonds */
	i = j = 0 ;
	while (ilss) {
/* as long as there are subbonds */
		if (i == j) {
/* cold start */
			for (x = 1 ; (x <= nass) && !( sub[x].ss_asgn && !sub[x].ss_init) ; x++)
				;
/* x is assigned but still not used */
			if (x > nass) {
/* no x available */
				for (x = 1 ; (x <= nass) && sub[x].ss_init ; x++)
					;
/* x is not used */
			}
			s1[i] = 0 ;
			s2[i] = x ;
			sub[x].ss_init = 1 ;
			i++;
/* x is now used. subbond 0-x stored */
		} else {
			x = s2[j] ;
			if (sub[x].ss_init == 1) {
/* x is an ending point that can be used as a new starting point */
				for (k = 0 ; k < sub[x].ss_nlia ; k++) {
					y = sub[x].ss_lia[k] ;
					e = sub[y].ss_init ;
/* y is the kth subneighbour of x. Its state is e */
					if (e != 2) {
/* y has never been used as starting point */
						s1[i] = x ;
						s2[i] = y ;
						i++;
						ilss--;
/* the bond x-y is now stored */
						if (!e) {
							sub[y].ss_init = 1 ;
/* if y has never been an ending point, it becomes an ending point */
						}
					}
				}
				sub[x].ss_init = 2 ;
/* x has been used as a starting point */
			}
			j++;
/* ready for the next starting point */
		}
	}
	if (flverb) {
/* listing of the assignment order */
		print_sub_index(f) ;
		printf("assignment order\nx : ") ;
		for (j = 0 ; j < i ; j++) {
			printf("%4d", sub[s1[j]].ss_ref) ;
		}
		printf("\n") ;
		printf("y : ") ;
		for (j = 0 ; j < i ; j++) {
			printf("%4d", sub[s2[j]].ss_ref) ;
		}
		printf("\n") ;
	}
	return i ;
/* sets the number of recursive steps in the assignment process */
}


int	print_sub_index(int f)
{
	if (f == 0) {
		printf("Native substructure: ") ;
	} else {
		printf("Substructure F%d: ", f) ;
	}
}


int	*serialize()
/*
 * builds a vector of integers that represents the current 
 * substructure (or fragment)
 */
{
	int sz, szs1s2, szsub ;
	int *data ;
	int *p ;

	szs1s2 = nssl * sizeof(int) ;
	szsub = nass * sizeof(struct ss_atom) ;
	sz = 2 * sizeof(int) + 2 * szs1s2 + szsub ;
/* for nass and nssl (2 ints), s1 and s2 (2*nssl ints) and nass ss_atoms */
	data = (int *)malloc(sz) ;
	if(data == NULL) return NULL ;
	p = data ;
	*p = nass ;
	p++ ;
	*p = nssl ;
	p++ ;
	if(nssl) {
		memcpy(p, s1, szs1s2) ;
		p += nssl ;
		memcpy(p, s2, szs1s2) ;
		p += nssl ;
	}
	if(nass) {
		memcpy(p, sub+1, szsub) ;
	}
	return data ;
}


int	critere(int x, int ssx)
/*
 * checks the compatibility between the atom x and the subatom ssx
 */
{
	return crit_e(x, ssx) &&  crit_h(x, ssx) &&  crit_m(x, ssx) ;
}


int	crit_e(int x, int ssx)
/* 
 * checks the identity of elements
 */
{
	int e ;

	e = sub[ssx].ss_element ;
	if (nucl[e].val < 0) {
		return 1 ;
/* atom type A, with valency -1, stands for any atom type - new with 3.1.4 */
	}
	return at[x].element == e ;
}


int	crit_h(int x, int ssx)
/* 
 * checks the compatibility of the hybridization states 
 */
{
	int	i, h, s ;

	h = sub[ssx].ss_hybrid ;
	if (h >= 0)
		return h == 3 - at[x].hybrid ;
	else {
		for (i = 0 ; i < (s = lnsize[-h]) &&  ln[-h][i] != 3 - at[x].hybrid ; i++) 
			;
		return i != s ;
	}
}

int	crit_m(int x, int ssx)
/* 
 * checks the compatibility of the multiplicities 
 */
{
	int	i, m, s ;

	m = sub[ssx].ss_mult ;
	if (m >= 0)
		return m == at[x].mult ;
	else {
		for (i = 0 ; i < (s = lnsize[-m]) &&  ln[-m][i] != at[x].mult ; i++)
			;
		return i != s ;
	}
}

int	attribuer(void)
/*
 * top level of the recursive assignment process
 */
{
	plvm logic ;

	if ((!flsubsgood) && (!flsubsbad)) {
                ss_ok = TRUE ;
        } else {
        	if (flfexp == 0) {
        		if (flnative == 0) {
        			ss_ok = TRUE ;
        		} else {
				ss_ok = fragment(0) ;
        		}
        	} else {
        		logic = (plvm)dyntext_serial_from_index(strtab, -1) ;
        		ss_ok = lvm_run(logic, fragment) ;
        	}
		if (flsubsbad) {
			ss_ok = !ss_ok ;
		}
        }
        return ss_ok ;
}

int	fragment(int f)
/*  returns true if fragment Ff is included inside of the current structure.
this function is of lvm_eval type (see lvm.h) */
{
	if (flverb) {
		print_sub_index(f) ;
		printf("search started.\n") ;
	}
	explode(f) ;
	ss_ok = FALSE ;
	attrib(0) ;
	if (flverb) {
		print_sub_index(f) ;
		printf("%s found.\n", ss_ok ? "" : "not ") ;
	}
	return ss_ok ;
}

void	explode(int f)
/*
 * reverses the action of serializes: restores substructure data
 * as if it alsways had been here. f is a substructure index,
 * like in Ff.
 */
{
	int *p, szs1s2, szsub ;
	int x, i ;

	reset_atom_asgn() ;
/* resets atom assignment */
	p = dyntext_serial_from_index(strtab, f) ;
	nass = *p ;
	p++ ;
	nssl = *p ;
	p++ ;
	szs1s2 = nssl * sizeof(int) ;
	szsub = nass * sizeof(struct ss_atom) ;
	if(nssl) {
		memcpy(s1, p, szs1s2) ;
		p += nssl ;
		memcpy(s2, p, szs1s2) ;
		p += nssl ;
	}
	if(nass) {
		memcpy(sub+1, p, szsub) ;
	}
/* restores s1, s2 and the subatoms */
	for(i = 1 ; i <= nass ; i++) {
		x = sub[i].ss_asgn ;
		if(x) {
			at[x].asgn = i ;
		}
	}
/* restores atom assignment(s) */
}


void	reset_atom_asgn(void)
/*
 * removes any previous assignment of an atom to a subatom
 */
{
	int x ;

	for(x = 1 ; x <= max_atomes ; x++) {
		if(at[x].utile) {
			at[x].asgn = 0 ;
		}
	}
}


void	attrib(int i)
/*
 * assignment of the substructure. nssl is now the number of assignment
 * steps (see main).
 */
{
	int	x, y, ssx, ssy, j ;

	if (i == nssl) {
		ss_ok = TRUE ;
		return ;
/* end condition of recursivity. if this point is reached the substructure
 * is fully assigned. That means it is present in the structure */
	}
	ssx = s1[i] ;
	ssy = s2[i] ;
	y = sub[ssy].ss_asgn ;
	if (ssx) {
		x = sub[ssx].ss_asgn ;
/* the starting subatom ssx is already assigned to x */
		if (y) {
/* if y is already assigned, too */
			if (estlie(x, y)) {
				attrib(i + 1) ;
/* and if x and y are bound, everything is ok. goes on. */
			} else {
				return ;
/* something is wrong somewhere. goes back. */
			}
		} else {
			for (j = 0 ; j < at[x].nlia ; j++) {
/* x <--> ssx. ssx is bound to ssy. therefore if y <--> ssy, x and y
 * have to be bound. y is x's jth neighbour. */
				y = at[x].lia[j] ;
				criter2(i, y, ssy) ;
/* checks if y and ssy have compatible status and call attrib at the next level.
   performs then the actual assignment job */
				if (ss_ok) {
					break ;
/* once all the assignments done there is no need to look for an other
 * possible assignments set. Assignment are never used in the solution output */ 
				}
			}
		}
	} else {
/* ssy is assigned from scratch */
		if (y) {
			attrib(i + 1) ;
/* if ssy is already assigned there is nothing to do */
		} else {
			for (y = 1 ; y <= max_atomes ; y++) {
				if (!at[y].utile) {
					continue ;
				}
				criter2(i, y, ssy) ;
/* checks if y and ssy have compatible status and call attrib at the next level.
   performs then the actual assignment job */
				if (ss_ok) {
					break ;
				}
			}
		}
	}
}


void	criter2(int i, int y, int ssy)
{
	if ((!at[y].asgn) && critere(y, ssy)) {
/* ssy has never been assigned, therefore y cannot be already assigned.
 * y and ssy must be compatible */
		if (flverb) 
			printf("assigns S%d to %d\n", sub[ssy].ss_ref, y) ;
		if (ok()) {
			marque () ;
			empile0(&(sub[ssy].ss_asgn), y) ;
			empile0(&(at[y].asgn), ssy) ;
			attrib(i + 1) ;
			relache() ;
/* updates assignement information, to be released after backtracking */
		}
	}
}


void	sub_about(void)
/*
 * prints everything about substructures
 */
{
	int i, l, f ;
	char *s ;

	l = dyntext_getlength(strtab) ;
	for(i=0 ; i<l ; i++) {
		f = dyntext_getindex(strtab, i) ;
		if(f >= 0) {
			s = dyntext_getstr(strtab, i) ;
			sub_about2(f, s) ;
		}
	}
}


void	sub_about2(int f, char *s)
/*
 * prints details about substructure (fragment) Ff from file s
 */
{
	int x, n, i ;

	if (strcmp(s, "NATIVE")) {
		printf("substructure from file: %s\n", s) ;
	} else {
		printf("native substructure\n") ;
	}
	explode(f) ;
	if(!nass) {
		printf("\tis empty\n") ;
		return ;
	}
	for (x = 1 ; x <= nass ; x++) {
		printf("\tsub-atom %d\n", sub[x].ss_ref) ;
		printf("\t\telement %s\n",  nucl[sub[x].ss_element].sym) ;
		printf("\t\tmultiplicity : ") ;
		wrln2(sub[x].ss_mult) ;
		printf("\t\thybridization : ") ;
		wrln2(sub[x].ss_hybrid) ;
		n = sub[x].ss_asgn ;
		if (n) {
			printf("\t\tassignment of atom : %d\n", n) ;
		}
		printf("\t\tbound to : ") ;
		for (i = 0 ; i < sub[x].ss_nlia ; i++) {
			printf("%d ", sub[sub[x].ss_lia[i]].ss_ref) ;
		}
		printf("\n") ;
	}
}
