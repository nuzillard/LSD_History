/*
    file: OutlsdSrc/outlsd.c
    Copyright(C)2000 CNRS - FRE 2715 - Jean-Marc Nuzillard

    This file is part of LSD.

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "defs.h"
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#define A -0.3
#define B 0.000001
#define C 0.2
#define E 0.5
#define THRS 1.0

struct atom at[MAX_ATOMES] ;
int isol ;
int max_atomes ;
char header[7] ;
int itt ;
int tt[MAX_TT][3] ;
int molflag = 0 ;

void pr_use()  ;
int lire() ;
void outlist() ;
void molheader() ;
void outmol() ;
void moltrailer() ;
void outugi() ; 
int insatur(int x) ;
void saut(int i) ;
void out3D(int p) ;
void minimiz(int nat, int fltt) ;
int bound(int i, int j) ;
int randexp() ;
double myrand(double range) ;
double car(double x)  ;
void wr3D(int n, int p) ;
void wr3djmn(int n) ;
void wr3dx(int n) ;
void wr3dmol(int n) ;

extern void smiles(struct atom at[], int max_atomes) ;
extern void out2D() ;
extern void wrMOL(int n) ;

double max_rand ;
struct at3D a[MAX_AT3D] ;

main(int argc, char *argv[])
{
	int p ; /* parameter passed to outlsd */
	int c ; /* current character */

	switch(argc) {
		case 2 : if(strlen(argv[1]) != 1) pr_use() ;
			 p = argv[1][0] - '0' ;
			 if(p<1 || p>8) pr_use() ;
			 break ;
		default : pr_use() ; break ;
	}
	c = fgetc(stdin) ;
	if(c == EOF) {
		printf("outlsd: input file is empty.\n") ;
		pr_use() ;
	}
	if(c == '#') {
/* there is a comment, reads until end of comment */
		while( ((c = fgetc(stdin)) != EOF) && (c != '#') )
			;
		if(c == EOF) {
			printf("outlsd: comment has no end.\n") ;
			pr_use() ;
		}
		c = fgetc(stdin) ; /* swallows the end of the line */
		if(c == EOF) {
			printf("outlsd: unexpected end-of-file.\n") ;
			pr_use() ;
		}
	} else {
/* no comment in input file */
		ungetc(c, stdin) ;
	}
	scanf("%6s", header) ;
	if(strcmp(header, "OUTLSD")) {
		printf("outlsd: donnees de type incorrect\n") ;
		exit(1) ;
	}
	max_rand = (exp(randexp()*log(2.0))) ;
	srand(1) ;
	if(p == 3) printf("JMNMOL\n") ;
	if(p == 6) printf("DRAW\n") ;
	if(p == 7) {
		molflag = 1 ;
	}
	while (lire()) 
		switch(p) {
			case 1 : outlist() ; break ;
			case 2 : outugi() ; break ;
			case 3 :  	/* pas de break */
			case 8 :  	/* pas de break */
			case 4 : out3D(p) ; break ; 
			case 5 : smiles (at, max_atomes) ; break ;
			case 6 : out2D() ; break ;
			case 7 : outmol() ; break ;
		}
	exit(0) ;
}

int lire()
{
	int i, x, v ;
	struct atom *a ;

	v = scanf("%d %d", &max_atomes, &isol) ;
	if(!v || !max_atomes) return FALSE ;
	for(x=1 ; x<=max_atomes ; x++) {
		a = &at[x] ;
		scanf(" %1d", &a->utile) ;
		if(a->utile == TRUE) {
			v = scanf(" %2s %1d %1d %1d %1d",
				a->elt,
				&a->valence,
				&a->mult,
				&a->nlmax,
				&a->nlia ) ;
			if(v != 5) return FALSE ;
			a->hybrid = a->valence - a->mult - a->nlmax ;
			for(i=0 ; i<4 ; i++) {
				v = scanf(" %3d %1d",
					&a->lia[i] ,
					&a->ordre[i] ) ;
				if(v != 2) return FALSE ;
			}
		} 
	}
/* The next line was missing. Bug corrected 05/14/2007 with version 3.2.1 */
	return TRUE ;
/* It is difficult to understand why it worked before. */
}

void pr_use() 
{
	printf("outlsd: usage : outlsd [12345678]\n") ;
	exit(1) ;
}

void outlist()
{
	int i, x, y, n ;
	struct atom *a ;

	printf("\n*** solution %d *** \n", isol) ;
	for(x=1 ; x<=max_atomes ; x++) if(at[x].utile) {
		a = &at[x] ;
		n = a->nlia ;
		for(i=0 ; i<n ; i++) {
			y = a->lia[i] ;
			if(x<y) printf("%4d%4d%2s\n",
				 x, y, (a->ordre[i]==1) ? " -" : " =") ;
		}
	}
}

void molheader()
{
	struct atom *a ;
	int i, x, na, nl ;

/* structures separation */

	printf("\n\n\n"); 

/* renumbering atoms, counting them, and counting bonds */

	na = 0 ;
	nl = 0 ;
	for(x=1 ; x <=max_atomes ; x++) {
		a = &at[x] ;
		if(a->utile && a->nlia) {
			na++ ;
			a->utile = na ;
/* this is bad bad bad. the utile field now contains the new atom number */
			nl += a->nlia ;
		}
	}
	nl /= 2 ;
	printf("%3d%3d  0  0  0  0  0  0  0  0  0 V2000\n", na, nl) ;
}

void outmol()
{
	molheader() ;
	out2D() ;
	moltrailer() ;
}

void moltrailer()
{
	struct atom *a ;
	int i, x, y, a1, a2 ;

	for(x=1 ; x<=max_atomes ; x++) {
		a = &at[x] ;
		a1 = a->utile ;
		if(a1) {
			for(i=0 ; i<(a->nlia) ; i++) {
				y = a->lia[i] ;
				if(x<y) {
					a2 = at[y].utile ;
					printf("%3d%3d%3d  0  0  0  0\n",
						a1, a2, a->ordre[i]) ;
				}
			}
		}
	}
	printf("M  END\n") ;
	printf("$$$$\n") ;
}


void outugi()
{
	struct atom *a ;
	int i, n, x, y, compt, iel ;
	char c, *adel, *pel, elmt[4] ;

	printf("%d\n", isol) ;
	compt = 0 ;
	for(x=1 ; x<=max_atomes ; x++) if(a = &at[x], a->utile) {
		adel = at[x].elt ;
		iel = 0 ;
		if(insatur(x)) elmt[iel++]='*';
		for(pel=adel ; (c = *pel) != '\0' ; iel++,pel++)
			elmt[iel]=c ;
		elmt[iel]='\0' ;
		printf("%4d%-4s0 010%1d  ", x, elmt, a->mult) ;
		saut(++compt) ;
	}
	printf("9999\n") ;
	compt = 0 ;
	for(x=1 ; x<=max_atomes ; x++) if(a = &at[x], a->utile) {
		n = a->nlia ;
		for(i=0 ; i<n ; i++) {
			y = a->lia[i] ;
			if(x<y) {
				printf("%4d%4d%1d0010   ",x, y, a->ordre[i]) ;
				saut(++compt) ;
			}
		}
	}
	printf("9999\n") ;
}

int insatur(int x)
{
	return at[x].nlmax - at[x].nlia ;
}

void saut(int i)
{
	if(i % 5 == 0) printf("\n") ;
}

void out3D(int p) 
{
	double arete ;
	int ia, z, i, j, v, iap, h, k, n, it, aj, ak, sw ;
	struct at3D *ai ;

	arete = exp(log((double)max_atomes)/3.0) ;
	for(ia=0,z=0 ; z<=max_atomes ; z++)
	    if(at[z].utile && at[z].nlia) {
		a[ia].nom = at[z].elt ;
		a[ia].nlien = at[z].nlia ;
		a[ia].nh = at[z].mult ;
		a[ia].loc = z ;
		at[z].loc3D = ia ;
		for(i=0 ; i<3 ; i++) a[ia].coor[i] = myrand(arete) ;
		for(i=0 ; i<6 ; i++) a[ia].lien[i] = 0 ;
		ia++ ;
	}
	for(i=0 ; i<ia ; i++) {
		z = a[i].loc ;
		n = at[z].nlia ;
		for(j=0 ; j<n ; j++) {
			v = at[z].lia[j] ;
			a[i].lien[j] = at[v].loc3D ;
			a[i].ordl[j] = at[z].ordre[j] ;
			a[i].flD[j] = TRUE ;
		}
	}
	itt = 0 ;
	for(i=0 ; i<ia ; i++) {
		ai = &a[i] ;
		h = at[ai->loc].hybrid ;
		n = ai->nlien ;
		for(j=0 ; j<n-1 ; j++) for(k=j+1 ; k<n ; k++) {
			aj = ai->lien[j] ;
			ak = ai->lien[k] ;
			if(aj > ak) {
				sw = aj ;
				aj = ak ;
				ak = sw ;
			}
			for(it=0 ; it<itt 
				&& !(tt[it][0]==aj && tt[it][1]==ak) ; it++) ;
			if(it == itt) {
				tt[itt][0] = aj ;
				tt[itt][1] = ak ;
				tt[itt][2] = h ;
				itt++ ;
				if(itt==MAX_TT) {
					printf("augmenter MAX_TT\n") ;
					exit(0) ;
				}
			}
		}
	}
	minimiz(ia, TRUE) ; 
	iap = ia ;
	if(p == 4) for(i=0 ; i<ia ; i++) {
		a[i].savnlien = a[i].nlien ;
		h = a[i].nh ;
		for(j=0 ; j<h ; j++) {
			a[iap].nom = "H" ;
			a[iap].nlien = 1 ;
			for(k=0 ; k<3 ; k++)
				a[iap].coor[k] = a[i].coor[k] + myrand(1.0) ;
			a[iap].lien[0] = i ;
			a[iap].ordl[0] = 1 ;
			a[iap].flD[0] = FALSE ;
			for(k=1 ; k<6 ; k++) a[iap].lien[k] = 0 ;
			a[i].lien[a[i].nlien] = iap ;
			a[i].ordl[a[i].nlien] = 1 ;
			a[i].flD[a[i].nlien] = FALSE ;
			a[i].nlien++ ;
			iap++ ;
		}
	}
	minimiz(iap, FALSE) ; 
	wr3D(iap, p) ; 
}
	
void minimiz(int nat, int fltt)
{
	struct at3D *ai, *aj ;
	int i, j, k, n, fli, flj, a1, a2, it ;
	double rms, v[3], D, f, r2, di ;

	rms = 1.0 ;
	for(n=0 ; n<MAX_ITER && rms>MAX_RMS ; n++) {
		for(i=0 ; i<nat ; i++) {
			ai = &a[i] ;
			for(j=0 ; j<3 ; j++) ai->dsp[j]=0.0 ;
			for(j=0 ; j<nat ; j++) {
				aj = &a[j] ;
				for(k=0 ; k<3 ; k++)
					v[k] = aj->coor[k] - ai->coor[k] ;
				r2 = car(v[0]) + car(v[1]) + car(v[2]) ;
				if(bound(i, j)) {
					fli = ai->nom[0] == 'H' ;
					flj = aj->nom[0] == 'H' ;
					D = (fli || flj) ? 0.25 : 1.0 ;
					f = C*(1-1/(r2/D + B)) ;
				}
				else f = A/car(r2+B) ;
				for(k=0 ; k<3 ; k++) ai->dsp[k] += f*v[k] ;
			}
		} 
		if(fltt) for(it=0 ; it<itt ; it++) {
			a1 = tt[it][0] ;
			a2 = tt[it][1] ;
			for(k=0 ; k<3 ; k++)
				v[k] = a[a2].coor[k] - a[a1].coor[k] ;
			r2 = car(v[0]) + car(v[1]) + car(v[2]) ;
			D = (tt[it][2]) ? 3.0 : 8.0/3.0 ;
			f = E*(1-1/(B + r2/D)) ;
			for(k=0 ; k<3 ; k++) {
				di = v[k] * f ;
				a[a2].dsp[k] -= di ;
				a[a1].dsp[k] += di ;
			}
		}
		rms = 0.0 ;
		for(i=0 ; i<nat ; i++) for(j=0 ; j<3 ; j++)
			rms += car(a[i].dsp[j]) ;
		rms = sqrt(rms/nat) ;
		f = (rms > THRS) ? THRS/rms : 1.0 ;
		for(i=0 ; i<nat ; i++) for(j=0 ; j<3 ; j++) 
			a[i].coor[j] += f * (a[i].dsp[j]) ;
	}
/*	for(it=0 ; it<itt ; it++) {
		a1 = tt[it][0] ;
		a2 = tt[it][1] ;
		for(k=0 ; k<3 ; k++)
			v[k] = a[a2].coor[k] - a[a1].coor[k] ;
		r2 = sqrt(car(v[0]) + car(v[1]) + car(v[2])) ;
		printf("%d %d %f\n", a1+1, a2+1, r2) ;
	}
*/
}

int bound(int i, int j)
{
	struct at3D *ai ;
	int n, nl ;

	ai = &a[i] ;
	nl = ai->nlien ;
	for(n=0 ; n<nl && ai->lien[n] != j ; n++) ;
	return n != nl ;
}

int randexp()
{
	int i, s ;

	s = 1<<15 ;
	for(i=0 ; i<100 ; i++) {
		if(rand() >= s) return 31 ;
	}
	return 15 ;
}

double myrand (double range)
{
	return (rand()/max_rand - 0.5)*range ;
}

double car(double x) 
{
	return x*x ;
}

void wr3D(int n, int p)
{
	switch(p) {
		case 3 : wr3djmn(n) ; break ;
		case 4 : wr3dx(n) ; break ;
		case 8 : wr3dmol(n) ; break ;
	}
}

void wr3djmn(int n)
{
	int i, j ;

	printf("%d 1.0 1.0 1.0 \n", n) ;
	for(i=0 ; i<n ; i++) {
		printf("%3s  ", a[i].nom) ;
		for(j=0 ; j<3 ; j++) printf("%10.5f ", a[i].coor[j]) ;
		for(j=0 ; j<a[i].nlien ; j++) printf("%5d", a[i].lien[j]+1) ;
		for(j=a[i].nlien ; j<6 ; j++) printf("%5d", 0) ;
		printf("\n") ;
	}
}

void wr3dx(int n)
{
	int i, j, z, zz, cx ;

	for(i=0 ; i<n ; i++) {
		switch(a[i].nom[0]) {
			case 'C' :
				z = a[i].loc ;
				switch(at[z].hybrid) {
					case 0 : cx = 3 ; break ;
					case 1 : cx = 2 ; break ;
				}
				break ;
			case 'O' : 
				z = a[i].loc ;
				switch(at[z].hybrid) {
					case 0 : cx = 16 ; break ;
					case 1 : cx = 15 ; break ;
				}
				break ;
			case 'N' : 
				z = a[i].loc ;
				switch(at[z].hybrid) {
					case 0 : 
for(j=0 ; j<at[z].nlia && (zz=at[z].lia[j], !at[zz].hybrid) ; j++) ;
cx = (j == at[z].nlia) ? 26 : 25 ;
					break ;
					case 1 : cx = 25 ; break ;
				}
				break ;
			case 'H' :
				switch(a[a[i].lien[0]].nom[0]) {
					case 'C' : cx = 41 ; break ;
					case 'O' : cx = 42 ; break ;
					case 'N' : cx = 43 ; break ;
				}
				break ;
		}
		a[i].typx = cx ;
	}
	printf("%6d   %d\n", n, isol) ;
	for(i=0 ; i<n ; i++) {	
		printf("%4d", a[i].typx) ;
		for(j=0 ; j<a[i].nlien ; j++) printf("%6d%2d",
			a[i].lien[j]+1, a[i].ordl[j]) ;
		for(j=a[i].nlien ; j<6 ; j++) printf("%6d%2d", 0, 0) ;
		for(j=0 ; j<3 ; j++) printf("%12.6f", a[i].coor[j]) ;
		printf("\n") ;
	}
}

void wr3dmol(int n)
{
	molheader() ;
	wrMOL(n) ;
	moltrailer() ;
}
