
    Copyright(C)2000 CNRS - FRE 2715 - Jean-Marc Nuzillard

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


1. Installation

See the INSTALL_ENG.html (in English) or the INSTALL_FR.html (in French) file.


2. Running LSD

See the MANUAL_ENG.html (in English) or the MANUAL_FR.html (in French) file.


3. Author

Jean-Marc Nuzillard
FRE 2715
University of Reims
France
http://www.univ-reims.fr/Labos/FRE2715

Please send your comments to jm.nuzillard@univ-reims.fr


4. Overview of the LSD program

The aim of the LSD program is to find all possible molecular
structures of an organic compound that are compatible
with its spectroscopic data.

Structure building relies on connectivity data found in 2D NMR
spectra, without any reference to a chemical shift database.
Molecular structures containing up to 50 non-hydrogen atoms were
investigated by means of the LSD program.

The measurement protocol that is required by LSD includes
the recording of 1D 1H and 13C as well as
2D COSY, HSQC and HMBC spectra.
The status of each atom must be defined. It includes
the atom symbol,the hybridization state (sp3 or sp2)
and the number of attached hydrogen atoms.
This part of the data set is most often easily deduced by the user
from elementary chemical shift knowledge.
The status of the heteroatoms is deduced from
the elemental molecular formula.

Carbon-carbon bonds are deduced from COSY and HSQC data
while HMBC and HSQC data provide connectivity relationships
through one or two bonds for non-hydrogen atom.
The constraints imposed by atom status and 2D NMR data
may be enforced by other atom neighborhood relationships.
For example, it is possible to force a carbon atom
to be bound only to carbon atoms.
The user is responsible for such supplementary data.
Contradictory constraints lead LSD to fail in the
search of a solution structure.

The low resolution of HMBC and HSQC spectra in the C-13
chemical shift domain causes peak assignment ambiguities.
It is possible to define groups of resonances
and to assign a HMBC correlation peak to a group.
This means that the correlation is caused by
at least one member of the group.

The solutions may be selected using a substructure.
Those violating Bredt's rule are also discarded.

The input to LSD is coded by the user as a text file,
according to the instructions in the MANUAL_ENG.html
(in English) or in the MANUAL_FR.html (in French) document.

A program named OUTLSD reads the generated solutions
and converts them into various formats: bonds lists,
2D coordinates, fancy 3D coordinates (fancy, due to
the lack of stereochemical information) for Macromodel,
SMILES chains and .mol data used by some commercial software.

Execution of the LSD program may be controlled by specific
instructions for output formatting such as: single step execution,
search of the biggest found fragment (for debugging purpose),
report writing, verbosity level, substructure search.

Dozens of structures were investigated by means of
the LSD program, essentially in the field of
natural product chemistry, and especially for
terpenes and alkaloids.
This work led to scientific publications:

J.-M. Nuzillard and G. Massiot.
Computer-aided spectral assignment in
nuclear magnetic resonance spectroscopy.
Analytica Chimica Acta 1991, 242, 37-41.

J.-M. Nuzillard and G. Massiot.
Logic for Structure Determination.
Tetrahedron 1991, 47, 3655-3664.

J.-M. Nuzillard.
A quick method for the automatic detection of anti-Bredt structures.
J. Chem. Inf. Comput. Sci., 1994, 34, 723-724.

S. V. Ley, K. Doherty, G. Massiot and J.-M. Nuzillard.
Connectivist approach to organic structure determination.
LSD-program assisted NMR analysis of the insect antifeedant azadirachtin.
Tetrahedron 1994, 50, 12267-12280.

J.-M. Nuzillard, W. Naanaa, and S. Pimont.
Applying the constraint satisfaction paradigm for structure generation.
J. Chem. Inf. Comput. Sci., 1995, 35, 1068-1073.

G. Almanza, L. Balderama, C. Labb&eacute;, C. Lavaud, G. Massiot, J.-M. Nuzillard,
J. D. Connolly, L. J. Farrugia, and D. S. Rycroft.
Clerodane diterpenoids and ursane triterpenoid from Salvia haenkei.
Computer-assisted structural elucidation.
Tetrahedron, 1997, 53, 14719-14728.

J.-M. Nuzillard.
Determination assistee par ordinateur de la
structure des molecules organiques.
J. Chim. Phys. 1998, 95, 169-177.

G. Massiot, C. Lavaud, and J.-M. Nuzillard.
Structure elucidation of plant secondary products.
Chemical from plants. Perspectives on plant secondary products.
Imperial College Press, 1999, pp. 187-214.

J.-M. Nuzillard, J. D. Connolly, C. Delaude, B. Richard, M. Zeches-Hanrot,
and L. Le Men-Olivier.
Computer-assisted structural elucidation.
Alkaloids with a novel diaza-adamantane skeleton from the seeds of
Acosnium panamense (Fabaceae).
Tetrahedron 1999, 55, 11511-11518.

D. Mulholland, M. Randrianarivelojosia, C. Lavaud,
J.-M. Nuzillard, and S. L. Schwikkard.
Limonoid derivatives from Astrotrichilia voamatata.
Phytochemistry 2000, 53, 115-118.

D. Mulholland, S. L. Schwikkard, P. Sandor, and J.-M. Nuzillard.
Delevoyin C, a tetranortriterpenoid from Entendophragma delevoyi.
Phytochemistry 2000, 53, 465-468.

J.-M. Nuzillard 
Automatic structure determination of organic molecules: principle and implementation of the LSD program.
Chinese Journal of Chemistry, 2003, 21, 1263-1267 

5. Files

The LSDos-3.1.10 directory contains the following files and directories

Data/ 		a directory with LSD data sets
filter.dat	a sample filter definition file
filter.pl	the filter command
filter.bat	a DOS wrapper around filter.pl
Filters/ 	a directory with solution filtering Perl modules and filter elements
HISTORY.html 	a short history of the LSD program
INSTALL_ENG.htmlinstallation instructions, in English
INSTALL_FR.html	installation instructions, in French
LICENSE.txt 	the text of the GNU Public Licence
MANUAL_ENG.html the LSD manual, in English
MANUAL_FR.html 	the LSD manual, in French
README.txt 	this file
TODO.txt	a very uncomplete list of things to do
dialog.tcl 	a Tcl/Tk script for dialog widgets
m_edit.tcl	a Tcl/Tk script for 2D structures editing
m_edit.bat	a DOS wrapper around m_edit.tcl
lsd.exe		lsd itself
outlsd.exe	the drawing generator
genpos.exe	the postscript generator

The Filters directory contains :

ring3		a generic 3-membered ring sub-structure definition
ring4		a generic 4-membered ring sub-structure definition
bin		a folder that contains SolnFilter.pm and SolnReader.pm Perl modules
Misc		a folder that contains four test files
