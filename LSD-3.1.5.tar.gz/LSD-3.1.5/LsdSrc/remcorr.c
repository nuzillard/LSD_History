/*
    file: LsdSrc/remcorr.c
    Copyright(C)2000 CNRS - UMR 6013 - Jean-Marc Nuzillard

    This file is part of LSD.

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "defs.h"
#include <stdio.h>

extern struct atom at[MAX_ATOMES] ; /* lsd.c */
extern int	valcorr[MAX_CORR] ; /* lsd.c */
extern int	base[MAX_ATOMES] ; /* lsd.c */
extern int	nbase ; /* lsd.c */
extern int	flverb ; /* lsd.c */
extern int	flhmbvar ; /* lsd.c */
extern int	lnsize[MAX_LN] ; /* lsd.c */
extern int	ln[MAX_LN][MAX_LNBUF] ; /* lsd.c */
extern int	nivheap ; /* lsd.c */

extern void	empile(int t, int a, int v) ; /* heap.c */
extern void	wrln2(int y) ; /* start1.c */

void	remcorr3(int fl, int n, int x, int y) ;
void	remcorr2(int x, int z) ;
void	remcorrvar(int x, int z) ;
void	inutil1(int x, int y) ;
void	inutil2(int x, int z, int y) ;
void	inutil4(int z, int x, int y) ;

void	remcorr3(int fl, int n, int x, int y)	
/*
 * removes the nth correlation, which is between x and y
 * if fl is true, it means that the correlation has to be removed because
 * it becomes obsolescent. This happens upon bond formation when
 * x and y become visible to each other (either directly bound, or both 
 * bound to a common atom. The correlation is then considered as a 
 * confirmation information. fl is false when the correlation has been
 * really used in order to establish bonds.
 */
{
	int	*a ;

	empile(0, (int)&valcorr[n], FALSE) ;	
/* the correlation is marked as unusable */
	a = &at[x].nc ;
/* address where x's number of valid correlations is stored */
	empile(0, (int)a, (*a) - 1) ;	
/* one less valid correlation for x */
	if (base[x] && !(*a)) {
/* if x belongs to the base and has no more correlation */
		empile(0, (int)&base[x], FALSE) ;
		empile(0, (int)&nbase , nbase - 1) ;
/* it is removed from the base */
	}
	if (y > 0) {	
/* the correlation has no variant : y is not a numeric list reference.
 * x'th number of correlations and the base content is modified as for x */
		a = &at[y].nc ;
		empile(0, (int)a, (*a) - 1) ;
		if (base[y] && !(*a)) {
			empile(0, (int)&base[y], FALSE) ;
			empile(0, (int)&nbase , nbase - 1) ;
		}
	}
	if (fl) {
/* for confirmation correlations */
		empile(3, x, y) ;
	}
	if (fl && flverb > 1) {
/* message for confirmation correlations */
		printf("%d : removes correlation %d - ", nivheap, x) ;
		wrln2(y) ;
	}
}


void	remcorr2(int x, int z) 
/*
 * removes the x-z correlation.  
 */
{
	int	i, c ;

	if ((!at[x].ingrp) && (!at[x].nc)) {
		return ;
	}
	if ((!at[z].ingrp) && (!at[z].nc)) {
		return ;
	}
/* if x is not a member of a group and has no correlation, there is no
 * correlation to remove. As well for z. */
	for (i = 0 ; i < at[x].nctot ; i++) {
		c = at[x].ex[i] ;
		if (valcorr[c] && (z == at[x].other[i])) {
			remcorr3(1, c, x, z) ;
/* correlation c between x and z must be removed */
		}
	}
	if (flhmbvar) {
/* either x or z may be member of a group */
		remcorrvar(x, z) ;
		remcorrvar(z, x) ;
	}
}


void	remcorrvar(int x, int z)
/*
 * removes an eventual correlation between x and a group containing z
 */
{
	int	c, z0, s, i, j ;

	if (at[x].corrgrp && at[z].ingrp) {
/* x correlates with a group andz belongs to a group */
		for (i = 0 ; i < at[x].nctot ; i++) {
			c = at[x].ex[i] ;
			z0 = at[x].other[i] ;
			if (valcorr[c] && (z0 < 0)) {
/* correlation c is valid and correlated x with the group z0 */
				s = lnsize[-z0] ;
				for (j = 0 ; j < s && ln[-z0][j] != z ; j++) 
					;
				if (j != s) {
/* if z belongs to this group, the x-z0 correlation must be removed */
					remcorr3(1, c, x, z0) ;
				}
			}
		}
	}
}


void	inutil1(int x, int y)
/*
 * if these is already a bond between y and an atom z, an eventual
 * x-z correlation only brings a confirmation
 */
{
	int	i, z ;

	for (i = 0 ; i < at[y].nlia ; i++) {
		z = at[y].lia[i] ;
		if (z != x) {
			remcorr2(x, z) ;
		}
	}
}



void	inutil2(int x, int z, int y)
/*
 * a new bond x-z is created. the bond z-y may or may not be already created 
 * x --------- z - - - - - y
 */
{
	inutil1(z, x) ;
/* looks for t bound to x and for a z-t correlation */
	remcorr2(x, y) ;
/* if x and y are correlating */
	remcorr2(z, x) ;
/* if x and z are correlating */
	inutil4(z, x, y) ;
/* looks for t bound to z, and to t-x and t-z correlations */
}


void	inutil4(int z, int x, int y)
/*
 * looks for t bound to z, and to t-x and t-z correlations
 */
{
	int	i, n, t ;

	n = at[z].nlia ;
	if (n <= 2) { 
		return ;
	}
/* if z is already bound to t (different from x and y), this point is
 * necesserely reached because z has then at least 3 bonds. It would save
 * time to ensure that for a given (x,y,z) triplet this point is only 
 * reached one time */
	for (i = 0 ; i < n ; i++) {
		t = at[z].lia[i] ;
		if (t != x && t != y) {
			remcorr2(x, t) ;
			remcorr2(y, t) ;
/* removes enventual x-t and y-t correlations */
		}
	}
}
