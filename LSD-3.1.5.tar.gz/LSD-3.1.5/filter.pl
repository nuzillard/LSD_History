#!/usr/bin/perl

use Filters::bin::SolnFilter ;

my $f = new SolnFilter ;

if($#ARGV == 0) {
# 1 argument on the command line, the name of the filter script file
	$f->read($ARGV[0]) ;
} else {
# 0 argument ($#ARGV is -1), use filter.dat as filter script file
	$f->read() ;
}
unless ($f->ok()) {
# filter initialization failed
	print $f->msg() . "\n" ;
	exit(1) ;
}
# does the job
$f->chkAllSolutions() ;
unless ($f->ok()) {
# an error has occured during solution processing
	print "Error :" ;
	print $f->msg() . "\n" ;
} else {
# prints statistics
	print "Kept: " ;
	print $f->nkept() ;
	print " Rejected: " ;
	print $f->nrejected() ;
	print "\n" ;
}
# normal exit
exit(0) ;




