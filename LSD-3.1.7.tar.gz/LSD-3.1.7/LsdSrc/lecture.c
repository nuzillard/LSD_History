/*
    file: LsdSrc/lecture.c
    Copyright(C)2000 CNRS - FRE 2715 - Jean-Marc Nuzillard

    This file is part of LSD.

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <string.h>
#include "defs.h"

void	lecture(void) ;
void	remcomment(void) ;
void	lirecom(int ic) ;
void	lireliste(void) ;
void	non_nul(int errno, int v) ;
int	z(char *noyau) ;
void	check_lecture(void) ;
void	check_list(int l)  ;
int	lnpos(void) ;

extern void	classe(int n, int t[]) ; /* lsd.c */
extern void	myexit(int i) ; /* lsd.c */

extern int	lnsize[MAX_LN] ;
extern int	ln[MAX_LN][MAX_LNBUF] ;
extern int	list[MAX_LIST][MAX_ATOMES] ;
extern FILE *fic1 ;

struct comtab coms[MAX_COM] = {
/*
 * field 1 : mnemonic
 * field 2 : number of arguments, -1 if it is a list (of unknown length)
 * field 3 : type of the arguments, see lirecom
 * field 4 : analysis priority order
 */
	{ "VALE", 2, "AI", 0 },
	{ "MULT", 4, "IAII", 1 },
	{ "LIST", -1, "L", 2 },
	{ "CARB", 1, "L", 2 },
	{ "HETE", 1, "L", 2 },
	{ "SP3 ", 1, "L", 2 },
	{ "SP2 ", 1, "L", 2 },
	{ "QUAT", 1, "L", 2 },
	{ "CH  ", 1, "L", 2 },
	{ "CH2 ", 1, "L", 2 },
	{ "CH3 ", 1, "L", 2 },
	{ "FULL", 1, "L", 2 },
	{ "GREQ", 2, "LI", 2 },
	{ "LEEQ", 2, "LI", 2 },
	{ "GRTH", 2, "LI", 2 },
	{ "LETH", 2, "LI", 2 },
	{ "UNIO", 3, "BBL", 2 },
	{ "INTE", 3, "BBL", 2 },
	{ "DIFF", 3, "BBL", 2 },
	{ "PROP", 3, "BIL", 3 },
	{ "BOND", 2, "II", 4 },
	{ "HMQC", 2, "II", 5 },
	{ "COSY", 2, "II", 6 },
	{ "HMBC", 2, "VI", 7 },
	{ "ENTR", 1, "I", 0 },
	{ "HIST", 1, "I", 0 },
	{ "DISP", 1, "I", 0 },
	{ "VERB", 1, "I", 0 },
	{ "PART", 1, "I", 0 },
	{ "STEP", 1, "I", 0 },
	{ "WORK", 1, "I", 0 },
	{ "MLEV", 1, "I", 0 },
	{ "SSTR", 4, "SAVV", 8 },
	{ "ASGN", 2, "SI", 9 },
	{ "LINK", 2, "SS", 10 }, 
	{ "DUPL", 1, "I", 0 },
	{ "SUBS", 1, "I", 0 },
	{ "ELIM", 2, "II", 0 },
	{ "FILT", 1, "I", 0 } /* 39 */
};


struct noy nucl[MAX_NUCL] = {
	{ "C", 4 },
	{ "N", 3 },
	{ "O", 2 },
	{ "X", 0 },
	{ "Y", 0 },
	{ "Z", 0 },
	{ "A", -1 }
};


struct crt cartes[MAX_CARTES] ;

int	lignes_lues = 0 ;
int	icarte = 0 ;
int	lnbuf[MAX_LNBUF] ;
int	ilnbuf ;
int	iln = 1;

void	lecture(void)
{
	char	c[5] ;
	int	ic, go, n ;

	go = TRUE ;
	while (go) {
		remcomment() ;
/* removes comment(s) if any */
		n = fscanf(fic1, " %4[A-Z 23]", c) ;
		non_nul(100, n) ;
/* read mnemonic */
		go = strcmp(c, "EXIT") ;
		if (!go) {
			break ;
		}
/* EXIT not encountered */
		lignes_lues++;
/* counts command lines */
		for (ic = 0 ; ic < MAX_COM && strcmp(coms[ic].op, c) ; ic++)
			;
		non_nul(101, MAX_COM - ic) ;
/* the mnemonic exists */
		lirecom(ic) ;
/* reads arguments following the mnemomic */
	}
	/*check_lecture() ; */
}


void	remcomment()
/*
 * a comment starts at a ; and ends up at the end of the line.
 */
{
	char	s[2] ;

	while (fscanf(fic1, " %1[;]", s)) {
		while ((getc(fic1)) != '\n') 
			;
	}
}


void	lirecom(int ic)
/* reads arguments */
{
	int	i, nf, fl, v, h ;
	char	f, noyau[3], l[2] ;

	cartes[icarte].opnum = ic ;
	cartes[icarte].ln = lignes_lues ;
	nf = coms[ic].fields ;
/* expected arguments number */
	fl = nf < 0 ;
	if (fl) {
		nf = -nf ;
	}
/* special case of enumerated lists */
	for (i = 0 ; i < nf ; i++) {
		f = coms[ic].forme[i] ;
/* expecting argument of type f. its value will be stored in v */
		switch (f) {
		case 'A' :
/* symbol of atom requested */
			non_nul(110, fscanf(fic1, "%s", noyau)) ;
			v = z(noyau) ;
/* v is the nucleus number */
			break ;
		case 'B' :
/* either a single integer or [Ll]stuck with an integer
 * that is either an integer or a logical list reference */
			h = fscanf(fic1, " %1[Ll]", l) ;
/* h is true if it is a list reference */
			non_nul(111, fscanf(fic1, "%d", &v)) ;
			if (h) {
				non_nul(112, v < MAX_LIST) ;
				v = -v ; 
/* the list reference is stored as its opposite
 * integer are stored as themselves */
			}
			break ;
		case 'L' :
/* a list reference */
			non_nul(113, fscanf(fic1, " %1[Ll]", l)) ;
			non_nul(114, fscanf(fic1, "%d", &v)) ;
			non_nul(115, v < MAX_LIST) ;
			break ;
		case 'I' :
/* an integer */
			non_nul(116, fscanf(fic1, "%d", &v)) ;
			break ;
		case 'V' :
/* a numeric list or a single integer. a numeric list is enclosed 
 * between brackets */
			h = fscanf(fic1, " %1[(]", l) ;
			if (h) {
/* this is a list */
				ilnbuf = 0 ;
/* index on numeric list buffer */
				do {
					non_nul(118, fscanf(fic1, "%d", &lnbuf[ilnbuf++])) ;

/* put integer into the buffer */
				} while ((!fscanf(fic1, " %1[)]", l)) && (ilnbuf < MAX_LNBUF)) ;
/* while no ) is encounterd */
				non_nul(119, MAX_LNBUF - ilnbuf) ;
				v = -lnpos() ;
/* lnpos stores the content of the buffer to its definive location
 * lnpos returns the numeric list number, stored as its opposite */
			} else 
				non_nul(120, fscanf(fic1, "%d", &v)) ;
/* single integer. It sign is not checked for... */
			break ;
		case 'S' :
/* subatome reference, starts with [Ss] */
			non_nul(121, fscanf(fic1, " %1[Ss]", l)) ;
			non_nul(122, fscanf(fic1, "%d", &v)) ;
		}
		cartes[icarte].pars[i] = v ;
/* v is stored */
	}
	if (fl) {
/* there is still the content of the list to read */
		lireliste() ;
	}
	icarte++;
/* next command */
	non_nul(117, MAX_CARTES - icarte) ;
}


int	lnpos(void)
{
	int	i, j ;

	classe(ilnbuf, lnbuf) ;
/* ordering numeric values in lnbuf */
	for (i = 1 ; i < iln ; i++) {
/* looking for the equality of lnbuf and a previously entered list */
		if (ilnbuf != lnsize[i]) {
			continue ;
/* they do not have the same number of elements */
		}
		for (j = 0 ; j < ilnbuf && lnbuf[j] == ln[i][j] ; j++) 
			;
		if (j == ilnbuf) {
			return i ;
/* ln[i] is identical to lnbuf, return i */
		}
	}
	for (j = 0 ; j < ilnbuf ; j++) 
		ln[iln][j] = lnbuf[j] ;
	lnsize[iln] = ilnbuf ;
/* stores lnbuf as ln[iln] and stores its size */
	i = iln++;
/* next list */
	non_nul(140, MAX_LN - iln) ;
	return i ;
}


void	lireliste(void)
{
	int	i, il, a ;

	il = cartes[icarte].pars[0] ;
	for (i = 0 ; i < MAX_ATOMES ; i++) {
		list[il][i] = FALSE ;
	}
/* resets the list */
	while (fscanf(fic1, "%d", &a)) {
		non_nul(121, a < MAX_ATOMES) ;
		non_nul(122, a > 0) ;
		list[il][a] = TRUE ;
/* reads the list */
	}
}


void	non_nul(int errno, int v)
/* 
 * prints a message if the value v is 0 
 */
{
#define MAX_MSG 64
	int	i ;
	static struct msg {
		int	errco ;
		char	*errmsg ;
	} msgs[MAX_MSG] = {
		{ 100, "command expected" },
		{ 101, "too many commands" },
		{ 110, "atom name expected" },
		{ 111, "integer expected" },
		{ 112, "too big list index" },
		{ 113, "L expected" },
		{ 114, "integer expected" },
		{ 115, "too big list index" },
		{ 116, "integer expected" },
		{ 118, ") expected" },
		{ 119, "too long list" },
		{ 120, "integer expected" },
		{ 117, "too many commands" },
		{ 121, "S expected" },
		{ 122, "integer expected after S" },
		{ 140, "too many lists (...)" },
		{ 121, "atom number is too big" },
		{ 122, "atom number is too small" },
		{ 131, "unknown atom type" },
		{ 200, "already defined valency" },
		{ 201, "null valency" },
		{ 210, "atom number is too big" },
		{ 211, "unknown hybridization state" },
		{ 212, "invalid number of bonds" },
		{ 213, "invalid valency" },
		{ 260, "undefined atom within a list" },
		{ 261, "undefined atom within a list" },
		{ 262, "empty list" },
		{ 270, "property of unknown atom" },
		{ 271, "undefined list" },
		{ 230, "hmqc correlation of unknown atom" },
		{ 231, "hmqc correlation of unknown proton" },
		{ 251, "hmbc correlation of unknown proton" },
		{ 250, "hmbc correlation of unknown atom" },
		{ 280, "first atom to bind is unknown" },
		{ 281, "second atom to bind is unknown" },
		{ 282, "bond already given" },
		{ 283, "too many bonds for the first atom" },
		{ 284, "too many bonds for the second atom" },
		{ 290, "empty list" },
		{ 300, "empty list" },
		{ 310, "empty list" },
		{ 320, "unknown atom" },
		{ 321, "undefined list" },
		{ 330, "null number of occurence" },
		{ 331, "uncoherent property" },
		{ 332, "uncoherent property" },
		{ 340, "bond and property mismatch" },
		{ 350, "invalid sub-atom reference" },
		{ 351, "duplicated sub-atom" },
		{ 352, "too many sub-atoms" },
		{ 353, "invalid sub-atom hybridization state" },
		{ 354, "invalid sub-atom multiplicity" },
		{ 360, "unknown sub-atom" },
		{ 361, "invalid assignment" },
		{ 362, "duplicate assignment" },
		{ 370, "too many bonds in sub-structure" },
		{ 371, "unknown first sub-atom" },
		{ 372, "unknown second sub-atom" },
		{ 373, "first sub-atom has too many bonds" },
		{ 374, "second sub-atom has too many bonds" },
		{ 380, "negative number of correlation" },
		{ 381, "negative number of bonds" },
		{ 382, "number of bonds is too small (< 4)" }
	};


	if (v) {
		return ;
/* nothing to do */
	}
	printf("error %d - %d commands read\n", errno, lignes_lues) ;
	for (i = 0 ; i < MAX_MSG && msgs[i].errco != errno ; i++) 
		;
	if (i != MAX_MSG) 
		printf("\t%s\n", msgs[i].errmsg) ;
/* prints the message */
	else {
		printf("unknown error !!!!\n") ;
/* should not happen */
	}
	check_lecture() ;
	myexit(-1) ;
}


int	z(char *noyau)
/* 
 * looks up in the nucl table in order to get the nucleus reference 
 */
{
	int	i ;

	for (i = 0 ; (i < MAX_NUCL) && strcmp(noyau, nucl[i].sym) ; i++)  
		;
	non_nul(131, MAX_NUCL - i) ;
	return i ;
}


void	check_lecture(void)
/* lists for each read command the command number,
 * the mnemonic, the arguments as the v values determined in lirecom */
{
	int	i, j, o, n, fl ;

	for (i = 0 ; i < icarte ; i++) {
		o = cartes[i].opnum ;
		n = coms[o].fields ;
		fl = n < 0 ;
/* for the LIST command */
		if (fl) {
			n = -n ;
		}
		printf("%4d : %4s  ", i + 1, coms[o].op) ;
		for (j = 0 ; j < n ; j++) {
			printf("%4d", cartes[i].pars[j]) ;
		}
		if (fl) {
			check_list(cartes[i].pars[0]) ;
		}
		printf("\n") ;
	}
/* could be done in a better way, but would be more expensive */
}


void	check_list(int l)
/*
 * displays a (logical) list 
 */
{
	int	i ;

	for (i = 0 ; i < MAX_ATOMES ; i++) {
		if (list[l][i]) {
			printf("%3d", i) ;
		}
	}
}


