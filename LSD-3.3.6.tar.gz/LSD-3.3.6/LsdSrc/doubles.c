/*
    file: LsdSrc/doubles.c
    Copyright(C)2000 CNRS - UMR 6229 - Jean-Marc Nuzillard

    This file is part of LSD.

    LSD is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    LSD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LSD; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "defs.h"

extern void	marque(void) ;
extern void	empile0(int *a, int v) ;
extern void	relache(void) ;

extern struct atom at[MAX_ATOMES] ;
extern int	max_atomes ;
extern int	flkeep ;

int	dou[MAX_ATOMES] ; /* true when the sp2 atom has got its double bond */
int	fldou ; /* true when the distribution of double bonds succeeds */
int	lan[MAX_ATOMES] ; /* logical "ancient" atom set - see abredt() */
int	lne[MAX_ATOMES] ; /* logical "new" atom set - see abredt()  */
int	lfu[MAX_ATOMES] ; /* logical "future" atom set - see abredt()  */
int	numdbbonds = 0 ; /* the double of the number of double bonds */

int	chkdb(void) ;
int	doublelia(void) ;
void	makedb(void) ;
int	db(void) ;
int	antibredt(void) ;
int	abredt(int a, int b, int c, int d, int e) ;

int	doublelia(void)
/*
 * initialises atoms for double bonds search
 * calls makedb, that sets fldou
 */
{
	int	i, x ;

	fldou = FALSE ;
	for (x = 1 ; x <= max_atomes ; x++) {
		dou[x] = FALSE ;
		for (i = 0 ; i < at[x].nlia ; i++) {
			at[x].ordre[i] = 1 ;
		}
	}
	makedb() ;
	flkeep = FALSE ; /* heap manager back to normal state */
	return fldou ;
}


void	makedb(void)
/*
 * builds the double bonds set recursively
 */
{
	int	i, j, y, z ;

	y = db() ; /* y is sp2 but it has no double bond yet */
	if (y) {   /* y is 0 when all sp2 atoms have a double bond */
		for (i = 0 ; i < at[y].nlia ; i++) {
			if (fldou) { 
/* a solution has been found, nothing to do anymore */
				break ;
			}
			z = at[y].lia[i] ; 
/* z is y's ith neighbour */
			if ((at[z].hybrid == 0) || dou[z]) {
/* z has to be sp2 and not involved in a double bond yet */
				continue ;
			}
			for (j = 0 ; (j < at[z].nlia) && (at[z].lia[j] != y) ; j++) 
/* y is z's jth neighbour */
				;
			marque() ;
/* a new group in the heap : y-z and z-y bonds are double
 * y and z are involved in a double bond */
			empile0(&(at[y].ordre[i]), 2) ;
			empile0(&(at[z].ordre[j]), 2) ;
			empile0(&(dou[y]), TRUE) ;
			empile0(&(dou[z]), TRUE) ;
			makedb() ;
/* find the next double bond */
			relache() ;
/* releases the data from the heap unless flkeep has become true, as it
 * happens when all double bonds have been found */
		}
	} else {
/* preserves information upon backtracting
 * double bonds have all been found */
		flkeep = fldou = TRUE ;
	}
}


int	db(void)
/*
 * tries first to look for an atom y bound to x, involved in a double bond.
 * y must be sp2 and not involved in a double bond.
 * This is intended to discover the systems of conjugated double bonds.
 * If no such x can be found, y is chosen as an sp2 atom not involved
 * in a double bond. If no y can be found the job is done.
 */
{
	int	go, x, y, i ;

	for (x = 1 ; x <= max_atomes ; x++) {
		if (!dou[x]) {
			continue ;
		}
		for (i = 0 ; i < at[x].nlia ; i++) {
			y = at[x].lia[i] ;
			go = dou[y] || (at[y].hybrid == 0) ;
			if (!go) {
				return y ;
			}
		}
	}
	for (y = 1 ; y <= max_atomes ; y++) {
		go = dou[y] || (at[y].hybrid == 0) ;
		if (!go) {
			return y ;
		}
	}
	return FALSE ;
}


int	antibredt(void)
/* 
 * looking for a-b=c(-d1)-d2) arrangements, and test them against Bredt'rule
 * see abredt
 */

 {
	int	b, c, d[2], i, id, na ;

	for (b = 1 ; b <= max_atomes ; b++) {
		if (at[b].utile && (na = at[b].nlia) >= 2) {
/* b has at has na neighbours  with na >=2 */
			for (i = 0 ; (i < na) && (at[b].ordre[i] == 1) ; i++) 
				;
/* b shares a double bond with its ith neighbour */
			if (i == na) {
				continue ;
/* b is not involved in a double bond, go on searching */
			}
			c = at[b].lia[i] ;
/* double bond b=c */
			if (at[c].nlia != 3) {
				continue ;
/* c has 3 bonds */
			}
			for (i = 0, id = 0 ; i < 3 ; i++) {
				if (at[c].ordre[i] == 1) {
					d[id++] = at[c].lia[i] ;
				}
			}
/* d[0] and d[1] are bound to c via single bonds */
			for (i = 0 ; i < na ; i++) {
				if ((at[b].ordre[i] == 1) && abredt(at[b].lia[i], b, c, d[0], d[1])) {
					return TRUE ;
				}
			}
/* a can be any atom bound to b through a single bond, it is the ith
 * neighbour of b. If abredt return true the structure is antibredt */
		}
	}
	return FALSE ;
/* the structure is not antibredt. It is a good one */
}


int	abredt(int a, int b, int c, int d, int e)
/*
 * looks for all the set (lan) of atoms separated from a by 4 or less bonds.
 * if d and e are simultaneously in this set, it means that the double bond
 * b=c is embedded in 2 rings of size less or equal to 7. The structure
 * is then declared as antibredt.
 */
{
	int	i, j, x, y, cf ;

	for (x = 1 ; x <= max_atomes ; x++) {
		lan[x] = lne[x] = FALSE ;
	}
	lne[a] = lan[a] = TRUE ;
/* lan and lne only contain a */
	for (i = 0 ; i < 4 ; i++) { /* 4 times the step of set enlargement */
		for (x = 1 ; x <= max_atomes ; x++) {
			lfu[x] = FALSE ;
/* reset the list of future set members */
		}
		cf = 0 ;
/* counts the number of elements in lfu */
		for (x = 1 ; x <= max_atomes ; x++) {
			if (lne[x]) {
/* x is an atom that has entered in lan during the last iteration
 * or it is a (for the first iteration */
				for (j = 0 ; j < at[x].nlia ; j++) {
					y = at[x].lia[j] ;
/* y is its jth neighbour */
					if ((y != b) && (y != c) && (!lan[y])) {
						lfu[y] = lan[y] = TRUE ;
						cf++;
					}
/* y is neither in lan nor it is b or c. it can enter into lan. */
				}
			}
		}
		if (cf == 0) {
			break ;
/* no new atom during the iteration. No need to go further */
		}
		for (x = 1 ; x <= max_atomes ; x++) {
			lne[x] = lfu[x] ;
/* the list of the atoms discovered during the iteration will be the
 * list of new atoms for the next iteration */
		}
	}
	return lan[d] && lan[e] ;
/* d and e must not be in lan, else abredt retuen true */
}


